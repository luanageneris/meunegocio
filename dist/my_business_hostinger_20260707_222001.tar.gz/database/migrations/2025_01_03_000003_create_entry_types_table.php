<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('entry_types', function (Blueprint $table) {
            $table->id();
            $table->string('name')->unique();
            $table->boolean('requires_collaborator')->default(false);
            $table->timestamps();
            $table->softDeletes();

            // Índices
            $table->index('requires_collaborator');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('entry_types');
    }
};
