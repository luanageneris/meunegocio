import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Api\EntryTypeController::index
* @see app/Http/Controllers/Api/EntryTypeController.php:14
* @route '/api/personalizar/entry-types'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/api/personalizar/entry-types',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\EntryTypeController::index
* @see app/Http/Controllers/Api/EntryTypeController.php:14
* @route '/api/personalizar/entry-types'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\EntryTypeController::index
* @see app/Http/Controllers/Api/EntryTypeController.php:14
* @route '/api/personalizar/entry-types'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\EntryTypeController::index
* @see app/Http/Controllers/Api/EntryTypeController.php:14
* @route '/api/personalizar/entry-types'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Api\EntryTypeController::index
* @see app/Http/Controllers/Api/EntryTypeController.php:14
* @route '/api/personalizar/entry-types'
*/
const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\EntryTypeController::index
* @see app/Http/Controllers/Api/EntryTypeController.php:14
* @route '/api/personalizar/entry-types'
*/
indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\EntryTypeController::index
* @see app/Http/Controllers/Api/EntryTypeController.php:14
* @route '/api/personalizar/entry-types'
*/
indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index.form = indexForm

/**
* @see \App\Http\Controllers\Api\EntryTypeController::withTrashed
* @see app/Http/Controllers/Api/EntryTypeController.php:79
* @route '/api/personalizar/entry-types/with-trashed'
*/
export const withTrashed = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: withTrashed.url(options),
    method: 'get',
})

withTrashed.definition = {
    methods: ["get","head"],
    url: '/api/personalizar/entry-types/with-trashed',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\EntryTypeController::withTrashed
* @see app/Http/Controllers/Api/EntryTypeController.php:79
* @route '/api/personalizar/entry-types/with-trashed'
*/
withTrashed.url = (options?: RouteQueryOptions) => {
    return withTrashed.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\EntryTypeController::withTrashed
* @see app/Http/Controllers/Api/EntryTypeController.php:79
* @route '/api/personalizar/entry-types/with-trashed'
*/
withTrashed.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: withTrashed.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\EntryTypeController::withTrashed
* @see app/Http/Controllers/Api/EntryTypeController.php:79
* @route '/api/personalizar/entry-types/with-trashed'
*/
withTrashed.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: withTrashed.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Api\EntryTypeController::withTrashed
* @see app/Http/Controllers/Api/EntryTypeController.php:79
* @route '/api/personalizar/entry-types/with-trashed'
*/
const withTrashedForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: withTrashed.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\EntryTypeController::withTrashed
* @see app/Http/Controllers/Api/EntryTypeController.php:79
* @route '/api/personalizar/entry-types/with-trashed'
*/
withTrashedForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: withTrashed.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\EntryTypeController::withTrashed
* @see app/Http/Controllers/Api/EntryTypeController.php:79
* @route '/api/personalizar/entry-types/with-trashed'
*/
withTrashedForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: withTrashed.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

withTrashed.form = withTrashedForm

/**
* @see \App\Http\Controllers\Api\EntryTypeController::show
* @see app/Http/Controllers/Api/EntryTypeController.php:34
* @route '/api/personalizar/entry-types/{entryType}'
*/
export const show = (args: { entryType: number | { id: number } } | [entryType: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/api/personalizar/entry-types/{entryType}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\EntryTypeController::show
* @see app/Http/Controllers/Api/EntryTypeController.php:34
* @route '/api/personalizar/entry-types/{entryType}'
*/
show.url = (args: { entryType: number | { id: number } } | [entryType: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { entryType: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { entryType: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            entryType: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        entryType: typeof args.entryType === 'object'
        ? args.entryType.id
        : args.entryType,
    }

    return show.definition.url
            .replace('{entryType}', parsedArgs.entryType.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\EntryTypeController::show
* @see app/Http/Controllers/Api/EntryTypeController.php:34
* @route '/api/personalizar/entry-types/{entryType}'
*/
show.get = (args: { entryType: number | { id: number } } | [entryType: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\EntryTypeController::show
* @see app/Http/Controllers/Api/EntryTypeController.php:34
* @route '/api/personalizar/entry-types/{entryType}'
*/
show.head = (args: { entryType: number | { id: number } } | [entryType: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Api\EntryTypeController::show
* @see app/Http/Controllers/Api/EntryTypeController.php:34
* @route '/api/personalizar/entry-types/{entryType}'
*/
const showForm = (args: { entryType: number | { id: number } } | [entryType: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\EntryTypeController::show
* @see app/Http/Controllers/Api/EntryTypeController.php:34
* @route '/api/personalizar/entry-types/{entryType}'
*/
showForm.get = (args: { entryType: number | { id: number } } | [entryType: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\EntryTypeController::show
* @see app/Http/Controllers/Api/EntryTypeController.php:34
* @route '/api/personalizar/entry-types/{entryType}'
*/
showForm.head = (args: { entryType: number | { id: number } } | [entryType: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

show.form = showForm

/**
* @see \App\Http\Controllers\Api\EntryTypeController::restore
* @see app/Http/Controllers/Api/EntryTypeController.php:90
* @route '/api/personalizar/entry-types/{id}/restore'
*/
export const restore = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: restore.url(args, options),
    method: 'post',
})

restore.definition = {
    methods: ["post"],
    url: '/api/personalizar/entry-types/{id}/restore',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\EntryTypeController::restore
* @see app/Http/Controllers/Api/EntryTypeController.php:90
* @route '/api/personalizar/entry-types/{id}/restore'
*/
restore.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    if (Array.isArray(args)) {
        args = {
            id: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        id: args.id,
    }

    return restore.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\EntryTypeController::restore
* @see app/Http/Controllers/Api/EntryTypeController.php:90
* @route '/api/personalizar/entry-types/{id}/restore'
*/
restore.post = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: restore.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Api\EntryTypeController::restore
* @see app/Http/Controllers/Api/EntryTypeController.php:90
* @route '/api/personalizar/entry-types/{id}/restore'
*/
const restoreForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: restore.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Api\EntryTypeController::restore
* @see app/Http/Controllers/Api/EntryTypeController.php:90
* @route '/api/personalizar/entry-types/{id}/restore'
*/
restoreForm.post = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: restore.url(args, options),
    method: 'post',
})

restore.form = restoreForm

/**
* @see \App\Http\Controllers\Api\EntryTypeController::store
* @see app/Http/Controllers/Api/EntryTypeController.php:24
* @route '/api/personalizar/entry-types'
*/
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/api/personalizar/entry-types',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\EntryTypeController::store
* @see app/Http/Controllers/Api/EntryTypeController.php:24
* @route '/api/personalizar/entry-types'
*/
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\EntryTypeController::store
* @see app/Http/Controllers/Api/EntryTypeController.php:24
* @route '/api/personalizar/entry-types'
*/
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Api\EntryTypeController::store
* @see app/Http/Controllers/Api/EntryTypeController.php:24
* @route '/api/personalizar/entry-types'
*/
const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Api\EntryTypeController::store
* @see app/Http/Controllers/Api/EntryTypeController.php:24
* @route '/api/personalizar/entry-types'
*/
storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

store.form = storeForm

/**
* @see \App\Http\Controllers\Api\EntryTypeController::update
* @see app/Http/Controllers/Api/EntryTypeController.php:43
* @route '/api/personalizar/entry-types/{entryType}'
*/
export const update = (args: { entryType: number | { id: number } } | [entryType: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/api/personalizar/entry-types/{entryType}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Api\EntryTypeController::update
* @see app/Http/Controllers/Api/EntryTypeController.php:43
* @route '/api/personalizar/entry-types/{entryType}'
*/
update.url = (args: { entryType: number | { id: number } } | [entryType: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { entryType: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { entryType: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            entryType: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        entryType: typeof args.entryType === 'object'
        ? args.entryType.id
        : args.entryType,
    }

    return update.definition.url
            .replace('{entryType}', parsedArgs.entryType.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\EntryTypeController::update
* @see app/Http/Controllers/Api/EntryTypeController.php:43
* @route '/api/personalizar/entry-types/{entryType}'
*/
update.put = (args: { entryType: number | { id: number } } | [entryType: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\Api\EntryTypeController::update
* @see app/Http/Controllers/Api/EntryTypeController.php:43
* @route '/api/personalizar/entry-types/{entryType}'
*/
const updateForm = (args: { entryType: number | { id: number } } | [entryType: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Api\EntryTypeController::update
* @see app/Http/Controllers/Api/EntryTypeController.php:43
* @route '/api/personalizar/entry-types/{entryType}'
*/
updateForm.put = (args: { entryType: number | { id: number } } | [entryType: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

update.form = updateForm

/**
* @see \App\Http\Controllers\Api\EntryTypeController::destroy
* @see app/Http/Controllers/Api/EntryTypeController.php:58
* @route '/api/personalizar/entry-types/{entryType}'
*/
export const destroy = (args: { entryType: number | { id: number } } | [entryType: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/api/personalizar/entry-types/{entryType}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Api\EntryTypeController::destroy
* @see app/Http/Controllers/Api/EntryTypeController.php:58
* @route '/api/personalizar/entry-types/{entryType}'
*/
destroy.url = (args: { entryType: number | { id: number } } | [entryType: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { entryType: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { entryType: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            entryType: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        entryType: typeof args.entryType === 'object'
        ? args.entryType.id
        : args.entryType,
    }

    return destroy.definition.url
            .replace('{entryType}', parsedArgs.entryType.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\EntryTypeController::destroy
* @see app/Http/Controllers/Api/EntryTypeController.php:58
* @route '/api/personalizar/entry-types/{entryType}'
*/
destroy.delete = (args: { entryType: number | { id: number } } | [entryType: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

/**
* @see \App\Http\Controllers\Api\EntryTypeController::destroy
* @see app/Http/Controllers/Api/EntryTypeController.php:58
* @route '/api/personalizar/entry-types/{entryType}'
*/
const destroyForm = (args: { entryType: number | { id: number } } | [entryType: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Api\EntryTypeController::destroy
* @see app/Http/Controllers/Api/EntryTypeController.php:58
* @route '/api/personalizar/entry-types/{entryType}'
*/
destroyForm.delete = (args: { entryType: number | { id: number } } | [entryType: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

destroy.form = destroyForm

const EntryTypeController = { index, withTrashed, show, restore, store, update, destroy }

export default EntryTypeController