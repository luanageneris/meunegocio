import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Api\CollaboratorController::index
* @see app/Http/Controllers/Api/CollaboratorController.php:17
* @route '/api/personalizar/collaborators'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/api/personalizar/collaborators',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\CollaboratorController::index
* @see app/Http/Controllers/Api/CollaboratorController.php:17
* @route '/api/personalizar/collaborators'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\CollaboratorController::index
* @see app/Http/Controllers/Api/CollaboratorController.php:17
* @route '/api/personalizar/collaborators'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\CollaboratorController::index
* @see app/Http/Controllers/Api/CollaboratorController.php:17
* @route '/api/personalizar/collaborators'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Api\CollaboratorController::index
* @see app/Http/Controllers/Api/CollaboratorController.php:17
* @route '/api/personalizar/collaborators'
*/
const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\CollaboratorController::index
* @see app/Http/Controllers/Api/CollaboratorController.php:17
* @route '/api/personalizar/collaborators'
*/
indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\CollaboratorController::index
* @see app/Http/Controllers/Api/CollaboratorController.php:17
* @route '/api/personalizar/collaborators'
*/
indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index.form = indexForm

/**
* @see \App\Http\Controllers\Api\CollaboratorController::withTrashed
* @see app/Http/Controllers/Api/CollaboratorController.php:30
* @route '/api/personalizar/collaborators/with-trashed'
*/
export const withTrashed = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: withTrashed.url(options),
    method: 'get',
})

withTrashed.definition = {
    methods: ["get","head"],
    url: '/api/personalizar/collaborators/with-trashed',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\CollaboratorController::withTrashed
* @see app/Http/Controllers/Api/CollaboratorController.php:30
* @route '/api/personalizar/collaborators/with-trashed'
*/
withTrashed.url = (options?: RouteQueryOptions) => {
    return withTrashed.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\CollaboratorController::withTrashed
* @see app/Http/Controllers/Api/CollaboratorController.php:30
* @route '/api/personalizar/collaborators/with-trashed'
*/
withTrashed.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: withTrashed.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\CollaboratorController::withTrashed
* @see app/Http/Controllers/Api/CollaboratorController.php:30
* @route '/api/personalizar/collaborators/with-trashed'
*/
withTrashed.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: withTrashed.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Api\CollaboratorController::withTrashed
* @see app/Http/Controllers/Api/CollaboratorController.php:30
* @route '/api/personalizar/collaborators/with-trashed'
*/
const withTrashedForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: withTrashed.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\CollaboratorController::withTrashed
* @see app/Http/Controllers/Api/CollaboratorController.php:30
* @route '/api/personalizar/collaborators/with-trashed'
*/
withTrashedForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: withTrashed.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\CollaboratorController::withTrashed
* @see app/Http/Controllers/Api/CollaboratorController.php:30
* @route '/api/personalizar/collaborators/with-trashed'
*/
withTrashedForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: withTrashed.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

withTrashed.form = withTrashedForm

/**
* @see \App\Http\Controllers\Api\CollaboratorController::show
* @see app/Http/Controllers/Api/CollaboratorController.php:87
* @route '/api/personalizar/collaborators/{collaborator}'
*/
export const show = (args: { collaborator: number | { id: number } } | [collaborator: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/api/personalizar/collaborators/{collaborator}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\CollaboratorController::show
* @see app/Http/Controllers/Api/CollaboratorController.php:87
* @route '/api/personalizar/collaborators/{collaborator}'
*/
show.url = (args: { collaborator: number | { id: number } } | [collaborator: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { collaborator: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { collaborator: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            collaborator: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        collaborator: typeof args.collaborator === 'object'
        ? args.collaborator.id
        : args.collaborator,
    }

    return show.definition.url
            .replace('{collaborator}', parsedArgs.collaborator.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\CollaboratorController::show
* @see app/Http/Controllers/Api/CollaboratorController.php:87
* @route '/api/personalizar/collaborators/{collaborator}'
*/
show.get = (args: { collaborator: number | { id: number } } | [collaborator: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\CollaboratorController::show
* @see app/Http/Controllers/Api/CollaboratorController.php:87
* @route '/api/personalizar/collaborators/{collaborator}'
*/
show.head = (args: { collaborator: number | { id: number } } | [collaborator: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Api\CollaboratorController::show
* @see app/Http/Controllers/Api/CollaboratorController.php:87
* @route '/api/personalizar/collaborators/{collaborator}'
*/
const showForm = (args: { collaborator: number | { id: number } } | [collaborator: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\CollaboratorController::show
* @see app/Http/Controllers/Api/CollaboratorController.php:87
* @route '/api/personalizar/collaborators/{collaborator}'
*/
showForm.get = (args: { collaborator: number | { id: number } } | [collaborator: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\CollaboratorController::show
* @see app/Http/Controllers/Api/CollaboratorController.php:87
* @route '/api/personalizar/collaborators/{collaborator}'
*/
showForm.head = (args: { collaborator: number | { id: number } } | [collaborator: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

show.form = showForm

/**
* @see \App\Http\Controllers\Api\CollaboratorController::getOrCreate
* @see app/Http/Controllers/Api/CollaboratorController.php:45
* @route '/api/personalizar/collaborators/get-or-create'
*/
export const getOrCreate = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: getOrCreate.url(options),
    method: 'post',
})

getOrCreate.definition = {
    methods: ["post"],
    url: '/api/personalizar/collaborators/get-or-create',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\CollaboratorController::getOrCreate
* @see app/Http/Controllers/Api/CollaboratorController.php:45
* @route '/api/personalizar/collaborators/get-or-create'
*/
getOrCreate.url = (options?: RouteQueryOptions) => {
    return getOrCreate.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\CollaboratorController::getOrCreate
* @see app/Http/Controllers/Api/CollaboratorController.php:45
* @route '/api/personalizar/collaborators/get-or-create'
*/
getOrCreate.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: getOrCreate.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Api\CollaboratorController::getOrCreate
* @see app/Http/Controllers/Api/CollaboratorController.php:45
* @route '/api/personalizar/collaborators/get-or-create'
*/
const getOrCreateForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: getOrCreate.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Api\CollaboratorController::getOrCreate
* @see app/Http/Controllers/Api/CollaboratorController.php:45
* @route '/api/personalizar/collaborators/get-or-create'
*/
getOrCreateForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: getOrCreate.url(options),
    method: 'post',
})

getOrCreate.form = getOrCreateForm

/**
* @see \App\Http\Controllers\Api\CollaboratorController::restore
* @see app/Http/Controllers/Api/CollaboratorController.php:146
* @route '/api/personalizar/collaborators/{id}/restore'
*/
export const restore = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: restore.url(args, options),
    method: 'post',
})

restore.definition = {
    methods: ["post"],
    url: '/api/personalizar/collaborators/{id}/restore',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\CollaboratorController::restore
* @see app/Http/Controllers/Api/CollaboratorController.php:146
* @route '/api/personalizar/collaborators/{id}/restore'
*/
restore.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    if (Array.isArray(args)) {
        args = {
            id: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        id: args.id,
    }

    return restore.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\CollaboratorController::restore
* @see app/Http/Controllers/Api/CollaboratorController.php:146
* @route '/api/personalizar/collaborators/{id}/restore'
*/
restore.post = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: restore.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Api\CollaboratorController::restore
* @see app/Http/Controllers/Api/CollaboratorController.php:146
* @route '/api/personalizar/collaborators/{id}/restore'
*/
const restoreForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: restore.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Api\CollaboratorController::restore
* @see app/Http/Controllers/Api/CollaboratorController.php:146
* @route '/api/personalizar/collaborators/{id}/restore'
*/
restoreForm.post = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: restore.url(args, options),
    method: 'post',
})

restore.form = restoreForm

/**
* @see \App\Http\Controllers\Api\CollaboratorController::store
* @see app/Http/Controllers/Api/CollaboratorController.php:74
* @route '/api/personalizar/collaborators'
*/
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/api/personalizar/collaborators',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\CollaboratorController::store
* @see app/Http/Controllers/Api/CollaboratorController.php:74
* @route '/api/personalizar/collaborators'
*/
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\CollaboratorController::store
* @see app/Http/Controllers/Api/CollaboratorController.php:74
* @route '/api/personalizar/collaborators'
*/
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Api\CollaboratorController::store
* @see app/Http/Controllers/Api/CollaboratorController.php:74
* @route '/api/personalizar/collaborators'
*/
const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Api\CollaboratorController::store
* @see app/Http/Controllers/Api/CollaboratorController.php:74
* @route '/api/personalizar/collaborators'
*/
storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

store.form = storeForm

/**
* @see \App\Http\Controllers\Api\CollaboratorController::update
* @see app/Http/Controllers/Api/CollaboratorController.php:100
* @route '/api/personalizar/collaborators/{collaborator}'
*/
export const update = (args: { collaborator: number | { id: number } } | [collaborator: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/api/personalizar/collaborators/{collaborator}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Api\CollaboratorController::update
* @see app/Http/Controllers/Api/CollaboratorController.php:100
* @route '/api/personalizar/collaborators/{collaborator}'
*/
update.url = (args: { collaborator: number | { id: number } } | [collaborator: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { collaborator: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { collaborator: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            collaborator: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        collaborator: typeof args.collaborator === 'object'
        ? args.collaborator.id
        : args.collaborator,
    }

    return update.definition.url
            .replace('{collaborator}', parsedArgs.collaborator.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\CollaboratorController::update
* @see app/Http/Controllers/Api/CollaboratorController.php:100
* @route '/api/personalizar/collaborators/{collaborator}'
*/
update.put = (args: { collaborator: number | { id: number } } | [collaborator: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\Api\CollaboratorController::update
* @see app/Http/Controllers/Api/CollaboratorController.php:100
* @route '/api/personalizar/collaborators/{collaborator}'
*/
const updateForm = (args: { collaborator: number | { id: number } } | [collaborator: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Api\CollaboratorController::update
* @see app/Http/Controllers/Api/CollaboratorController.php:100
* @route '/api/personalizar/collaborators/{collaborator}'
*/
updateForm.put = (args: { collaborator: number | { id: number } } | [collaborator: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

update.form = updateForm

/**
* @see \App\Http\Controllers\Api\CollaboratorController::destroy
* @see app/Http/Controllers/Api/CollaboratorController.php:119
* @route '/api/personalizar/collaborators/{collaborator}'
*/
export const destroy = (args: { collaborator: number | { id: number } } | [collaborator: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/api/personalizar/collaborators/{collaborator}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Api\CollaboratorController::destroy
* @see app/Http/Controllers/Api/CollaboratorController.php:119
* @route '/api/personalizar/collaborators/{collaborator}'
*/
destroy.url = (args: { collaborator: number | { id: number } } | [collaborator: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { collaborator: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { collaborator: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            collaborator: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        collaborator: typeof args.collaborator === 'object'
        ? args.collaborator.id
        : args.collaborator,
    }

    return destroy.definition.url
            .replace('{collaborator}', parsedArgs.collaborator.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\CollaboratorController::destroy
* @see app/Http/Controllers/Api/CollaboratorController.php:119
* @route '/api/personalizar/collaborators/{collaborator}'
*/
destroy.delete = (args: { collaborator: number | { id: number } } | [collaborator: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

/**
* @see \App\Http\Controllers\Api\CollaboratorController::destroy
* @see app/Http/Controllers/Api/CollaboratorController.php:119
* @route '/api/personalizar/collaborators/{collaborator}'
*/
const destroyForm = (args: { collaborator: number | { id: number } } | [collaborator: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Api\CollaboratorController::destroy
* @see app/Http/Controllers/Api/CollaboratorController.php:119
* @route '/api/personalizar/collaborators/{collaborator}'
*/
destroyForm.delete = (args: { collaborator: number | { id: number } } | [collaborator: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

destroy.form = destroyForm

const CollaboratorController = { index, withTrashed, show, getOrCreate, restore, store, update, destroy }

export default CollaboratorController