import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Api\HistoryController::stats
* @see app/Http/Controllers/Api/HistoryController.php:101
* @route '/api/history/stats'
*/
export const stats = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: stats.url(options),
    method: 'get',
})

stats.definition = {
    methods: ["get","head"],
    url: '/api/history/stats',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\HistoryController::stats
* @see app/Http/Controllers/Api/HistoryController.php:101
* @route '/api/history/stats'
*/
stats.url = (options?: RouteQueryOptions) => {
    return stats.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\HistoryController::stats
* @see app/Http/Controllers/Api/HistoryController.php:101
* @route '/api/history/stats'
*/
stats.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: stats.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\HistoryController::stats
* @see app/Http/Controllers/Api/HistoryController.php:101
* @route '/api/history/stats'
*/
stats.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: stats.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Api\HistoryController::stats
* @see app/Http/Controllers/Api/HistoryController.php:101
* @route '/api/history/stats'
*/
const statsForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: stats.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\HistoryController::stats
* @see app/Http/Controllers/Api/HistoryController.php:101
* @route '/api/history/stats'
*/
statsForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: stats.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\HistoryController::stats
* @see app/Http/Controllers/Api/HistoryController.php:101
* @route '/api/history/stats'
*/
statsForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: stats.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

stats.form = statsForm

/**
* @see \App\Http\Controllers\Api\HistoryController::modelHistory
* @see app/Http/Controllers/Api/HistoryController.php:154
* @route '/api/history/model-history'
*/
export const modelHistory = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: modelHistory.url(options),
    method: 'get',
})

modelHistory.definition = {
    methods: ["get","head"],
    url: '/api/history/model-history',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\HistoryController::modelHistory
* @see app/Http/Controllers/Api/HistoryController.php:154
* @route '/api/history/model-history'
*/
modelHistory.url = (options?: RouteQueryOptions) => {
    return modelHistory.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\HistoryController::modelHistory
* @see app/Http/Controllers/Api/HistoryController.php:154
* @route '/api/history/model-history'
*/
modelHistory.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: modelHistory.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\HistoryController::modelHistory
* @see app/Http/Controllers/Api/HistoryController.php:154
* @route '/api/history/model-history'
*/
modelHistory.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: modelHistory.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Api\HistoryController::modelHistory
* @see app/Http/Controllers/Api/HistoryController.php:154
* @route '/api/history/model-history'
*/
const modelHistoryForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: modelHistory.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\HistoryController::modelHistory
* @see app/Http/Controllers/Api/HistoryController.php:154
* @route '/api/history/model-history'
*/
modelHistoryForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: modelHistory.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\HistoryController::modelHistory
* @see app/Http/Controllers/Api/HistoryController.php:154
* @route '/api/history/model-history'
*/
modelHistoryForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: modelHistory.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

modelHistory.form = modelHistoryForm

/**
* @see \App\Http\Controllers\Api\HistoryController::show
* @see app/Http/Controllers/Api/HistoryController.php:78
* @route '/api/history/{id}'
*/
export const show = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/api/history/{id}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\HistoryController::show
* @see app/Http/Controllers/Api/HistoryController.php:78
* @route '/api/history/{id}'
*/
show.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    if (Array.isArray(args)) {
        args = {
            id: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        id: args.id,
    }

    return show.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\HistoryController::show
* @see app/Http/Controllers/Api/HistoryController.php:78
* @route '/api/history/{id}'
*/
show.get = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\HistoryController::show
* @see app/Http/Controllers/Api/HistoryController.php:78
* @route '/api/history/{id}'
*/
show.head = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Api\HistoryController::show
* @see app/Http/Controllers/Api/HistoryController.php:78
* @route '/api/history/{id}'
*/
const showForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\HistoryController::show
* @see app/Http/Controllers/Api/HistoryController.php:78
* @route '/api/history/{id}'
*/
showForm.get = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\HistoryController::show
* @see app/Http/Controllers/Api/HistoryController.php:78
* @route '/api/history/{id}'
*/
showForm.head = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

show.form = showForm

/**
* @see \App\Http\Controllers\Api\HistoryController::index
* @see app/Http/Controllers/Api/HistoryController.php:14
* @route '/api/history'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/api/history',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\HistoryController::index
* @see app/Http/Controllers/Api/HistoryController.php:14
* @route '/api/history'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\HistoryController::index
* @see app/Http/Controllers/Api/HistoryController.php:14
* @route '/api/history'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\HistoryController::index
* @see app/Http/Controllers/Api/HistoryController.php:14
* @route '/api/history'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Api\HistoryController::index
* @see app/Http/Controllers/Api/HistoryController.php:14
* @route '/api/history'
*/
const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\HistoryController::index
* @see app/Http/Controllers/Api/HistoryController.php:14
* @route '/api/history'
*/
indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\HistoryController::index
* @see app/Http/Controllers/Api/HistoryController.php:14
* @route '/api/history'
*/
indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index.form = indexForm

const HistoryController = { stats, modelHistory, show, index }

export default HistoryController