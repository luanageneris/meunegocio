import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Api\FinancialRecordController::index
* @see app/Http/Controllers/Api/FinancialRecordController.php:18
* @route '/api/registros/financial-records'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/api/registros/financial-records',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\FinancialRecordController::index
* @see app/Http/Controllers/Api/FinancialRecordController.php:18
* @route '/api/registros/financial-records'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\FinancialRecordController::index
* @see app/Http/Controllers/Api/FinancialRecordController.php:18
* @route '/api/registros/financial-records'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\FinancialRecordController::index
* @see app/Http/Controllers/Api/FinancialRecordController.php:18
* @route '/api/registros/financial-records'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Api\FinancialRecordController::index
* @see app/Http/Controllers/Api/FinancialRecordController.php:18
* @route '/api/registros/financial-records'
*/
const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\FinancialRecordController::index
* @see app/Http/Controllers/Api/FinancialRecordController.php:18
* @route '/api/registros/financial-records'
*/
indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\FinancialRecordController::index
* @see app/Http/Controllers/Api/FinancialRecordController.php:18
* @route '/api/registros/financial-records'
*/
indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index.form = indexForm

/**
* @see \App\Http\Controllers\Api\FinancialRecordController::show
* @see app/Http/Controllers/Api/FinancialRecordController.php:59
* @route '/api/registros/financial-records/{financialRecord}'
*/
export const show = (args: { financialRecord: number | { id: number } } | [financialRecord: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/api/registros/financial-records/{financialRecord}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\FinancialRecordController::show
* @see app/Http/Controllers/Api/FinancialRecordController.php:59
* @route '/api/registros/financial-records/{financialRecord}'
*/
show.url = (args: { financialRecord: number | { id: number } } | [financialRecord: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { financialRecord: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { financialRecord: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            financialRecord: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        financialRecord: typeof args.financialRecord === 'object'
        ? args.financialRecord.id
        : args.financialRecord,
    }

    return show.definition.url
            .replace('{financialRecord}', parsedArgs.financialRecord.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\FinancialRecordController::show
* @see app/Http/Controllers/Api/FinancialRecordController.php:59
* @route '/api/registros/financial-records/{financialRecord}'
*/
show.get = (args: { financialRecord: number | { id: number } } | [financialRecord: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\FinancialRecordController::show
* @see app/Http/Controllers/Api/FinancialRecordController.php:59
* @route '/api/registros/financial-records/{financialRecord}'
*/
show.head = (args: { financialRecord: number | { id: number } } | [financialRecord: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Api\FinancialRecordController::show
* @see app/Http/Controllers/Api/FinancialRecordController.php:59
* @route '/api/registros/financial-records/{financialRecord}'
*/
const showForm = (args: { financialRecord: number | { id: number } } | [financialRecord: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\FinancialRecordController::show
* @see app/Http/Controllers/Api/FinancialRecordController.php:59
* @route '/api/registros/financial-records/{financialRecord}'
*/
showForm.get = (args: { financialRecord: number | { id: number } } | [financialRecord: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\FinancialRecordController::show
* @see app/Http/Controllers/Api/FinancialRecordController.php:59
* @route '/api/registros/financial-records/{financialRecord}'
*/
showForm.head = (args: { financialRecord: number | { id: number } } | [financialRecord: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

show.form = showForm

/**
* @see \App\Http\Controllers\Api\FinancialRecordController::byDate
* @see app/Http/Controllers/Api/FinancialRecordController.php:127
* @route '/api/registros/financial-records/by-date/{date}'
*/
export const byDate = (args: { date: string | number } | [date: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: byDate.url(args, options),
    method: 'get',
})

byDate.definition = {
    methods: ["get","head"],
    url: '/api/registros/financial-records/by-date/{date}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\FinancialRecordController::byDate
* @see app/Http/Controllers/Api/FinancialRecordController.php:127
* @route '/api/registros/financial-records/by-date/{date}'
*/
byDate.url = (args: { date: string | number } | [date: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { date: args }
    }

    if (Array.isArray(args)) {
        args = {
            date: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        date: args.date,
    }

    return byDate.definition.url
            .replace('{date}', parsedArgs.date.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\FinancialRecordController::byDate
* @see app/Http/Controllers/Api/FinancialRecordController.php:127
* @route '/api/registros/financial-records/by-date/{date}'
*/
byDate.get = (args: { date: string | number } | [date: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: byDate.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\FinancialRecordController::byDate
* @see app/Http/Controllers/Api/FinancialRecordController.php:127
* @route '/api/registros/financial-records/by-date/{date}'
*/
byDate.head = (args: { date: string | number } | [date: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: byDate.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Api\FinancialRecordController::byDate
* @see app/Http/Controllers/Api/FinancialRecordController.php:127
* @route '/api/registros/financial-records/by-date/{date}'
*/
const byDateForm = (args: { date: string | number } | [date: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: byDate.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\FinancialRecordController::byDate
* @see app/Http/Controllers/Api/FinancialRecordController.php:127
* @route '/api/registros/financial-records/by-date/{date}'
*/
byDateForm.get = (args: { date: string | number } | [date: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: byDate.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\FinancialRecordController::byDate
* @see app/Http/Controllers/Api/FinancialRecordController.php:127
* @route '/api/registros/financial-records/by-date/{date}'
*/
byDateForm.head = (args: { date: string | number } | [date: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: byDate.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

byDate.form = byDateForm

/**
* @see \App\Http\Controllers\Api\FinancialRecordController::clearAll
* @see app/Http/Controllers/Api/FinancialRecordController.php:240
* @route '/api/registros/financial-records/clear-all'
*/
export const clearAll = (options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: clearAll.url(options),
    method: 'delete',
})

clearAll.definition = {
    methods: ["delete"],
    url: '/api/registros/financial-records/clear-all',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Api\FinancialRecordController::clearAll
* @see app/Http/Controllers/Api/FinancialRecordController.php:240
* @route '/api/registros/financial-records/clear-all'
*/
clearAll.url = (options?: RouteQueryOptions) => {
    return clearAll.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\FinancialRecordController::clearAll
* @see app/Http/Controllers/Api/FinancialRecordController.php:240
* @route '/api/registros/financial-records/clear-all'
*/
clearAll.delete = (options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: clearAll.url(options),
    method: 'delete',
})

/**
* @see \App\Http\Controllers\Api\FinancialRecordController::clearAll
* @see app/Http/Controllers/Api/FinancialRecordController.php:240
* @route '/api/registros/financial-records/clear-all'
*/
const clearAllForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: clearAll.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Api\FinancialRecordController::clearAll
* @see app/Http/Controllers/Api/FinancialRecordController.php:240
* @route '/api/registros/financial-records/clear-all'
*/
clearAllForm.delete = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: clearAll.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

clearAll.form = clearAllForm

/**
* @see \App\Http\Controllers\Api\FinancialRecordController::betweenDates
* @see app/Http/Controllers/Api/FinancialRecordController.php:140
* @route '/api/registros/financial-records/between-dates'
*/
export const betweenDates = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: betweenDates.url(options),
    method: 'post',
})

betweenDates.definition = {
    methods: ["post"],
    url: '/api/registros/financial-records/between-dates',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\FinancialRecordController::betweenDates
* @see app/Http/Controllers/Api/FinancialRecordController.php:140
* @route '/api/registros/financial-records/between-dates'
*/
betweenDates.url = (options?: RouteQueryOptions) => {
    return betweenDates.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\FinancialRecordController::betweenDates
* @see app/Http/Controllers/Api/FinancialRecordController.php:140
* @route '/api/registros/financial-records/between-dates'
*/
betweenDates.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: betweenDates.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Api\FinancialRecordController::betweenDates
* @see app/Http/Controllers/Api/FinancialRecordController.php:140
* @route '/api/registros/financial-records/between-dates'
*/
const betweenDatesForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: betweenDates.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Api\FinancialRecordController::betweenDates
* @see app/Http/Controllers/Api/FinancialRecordController.php:140
* @route '/api/registros/financial-records/between-dates'
*/
betweenDatesForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: betweenDates.url(options),
    method: 'post',
})

betweenDates.form = betweenDatesForm

/**
* @see \App\Http\Controllers\Api\FinancialRecordController::dailyTotals
* @see app/Http/Controllers/Api/FinancialRecordController.php:206
* @route '/api/registros/financial-records/daily-totals'
*/
export const dailyTotals = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: dailyTotals.url(options),
    method: 'post',
})

dailyTotals.definition = {
    methods: ["post"],
    url: '/api/registros/financial-records/daily-totals',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\FinancialRecordController::dailyTotals
* @see app/Http/Controllers/Api/FinancialRecordController.php:206
* @route '/api/registros/financial-records/daily-totals'
*/
dailyTotals.url = (options?: RouteQueryOptions) => {
    return dailyTotals.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\FinancialRecordController::dailyTotals
* @see app/Http/Controllers/Api/FinancialRecordController.php:206
* @route '/api/registros/financial-records/daily-totals'
*/
dailyTotals.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: dailyTotals.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Api\FinancialRecordController::dailyTotals
* @see app/Http/Controllers/Api/FinancialRecordController.php:206
* @route '/api/registros/financial-records/daily-totals'
*/
const dailyTotalsForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: dailyTotals.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Api\FinancialRecordController::dailyTotals
* @see app/Http/Controllers/Api/FinancialRecordController.php:206
* @route '/api/registros/financial-records/daily-totals'
*/
dailyTotalsForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: dailyTotals.url(options),
    method: 'post',
})

dailyTotals.form = dailyTotalsForm

/**
* @see \App\Http\Controllers\Api\FinancialRecordController::restore
* @see app/Http/Controllers/Api/FinancialRecordController.php:103
* @route '/api/registros/financial-records/{id}/restore'
*/
export const restore = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: restore.url(args, options),
    method: 'post',
})

restore.definition = {
    methods: ["post"],
    url: '/api/registros/financial-records/{id}/restore',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\FinancialRecordController::restore
* @see app/Http/Controllers/Api/FinancialRecordController.php:103
* @route '/api/registros/financial-records/{id}/restore'
*/
restore.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    if (Array.isArray(args)) {
        args = {
            id: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        id: args.id,
    }

    return restore.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\FinancialRecordController::restore
* @see app/Http/Controllers/Api/FinancialRecordController.php:103
* @route '/api/registros/financial-records/{id}/restore'
*/
restore.post = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: restore.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Api\FinancialRecordController::restore
* @see app/Http/Controllers/Api/FinancialRecordController.php:103
* @route '/api/registros/financial-records/{id}/restore'
*/
const restoreForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: restore.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Api\FinancialRecordController::restore
* @see app/Http/Controllers/Api/FinancialRecordController.php:103
* @route '/api/registros/financial-records/{id}/restore'
*/
restoreForm.post = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: restore.url(args, options),
    method: 'post',
})

restore.form = restoreForm

/**
* @see \App\Http\Controllers\Api\FinancialRecordController::store
* @see app/Http/Controllers/Api/FinancialRecordController.php:49
* @route '/api/registros/financial-records'
*/
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/api/registros/financial-records',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\FinancialRecordController::store
* @see app/Http/Controllers/Api/FinancialRecordController.php:49
* @route '/api/registros/financial-records'
*/
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\FinancialRecordController::store
* @see app/Http/Controllers/Api/FinancialRecordController.php:49
* @route '/api/registros/financial-records'
*/
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Api\FinancialRecordController::store
* @see app/Http/Controllers/Api/FinancialRecordController.php:49
* @route '/api/registros/financial-records'
*/
const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Api\FinancialRecordController::store
* @see app/Http/Controllers/Api/FinancialRecordController.php:49
* @route '/api/registros/financial-records'
*/
storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

store.form = storeForm

/**
* @see \App\Http\Controllers\Api\FinancialRecordController::update
* @see app/Http/Controllers/Api/FinancialRecordController.php:71
* @route '/api/registros/financial-records/{financialRecord}'
*/
export const update = (args: { financialRecord: number | { id: number } } | [financialRecord: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/api/registros/financial-records/{financialRecord}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Api\FinancialRecordController::update
* @see app/Http/Controllers/Api/FinancialRecordController.php:71
* @route '/api/registros/financial-records/{financialRecord}'
*/
update.url = (args: { financialRecord: number | { id: number } } | [financialRecord: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { financialRecord: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { financialRecord: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            financialRecord: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        financialRecord: typeof args.financialRecord === 'object'
        ? args.financialRecord.id
        : args.financialRecord,
    }

    return update.definition.url
            .replace('{financialRecord}', parsedArgs.financialRecord.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\FinancialRecordController::update
* @see app/Http/Controllers/Api/FinancialRecordController.php:71
* @route '/api/registros/financial-records/{financialRecord}'
*/
update.put = (args: { financialRecord: number | { id: number } } | [financialRecord: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\Api\FinancialRecordController::update
* @see app/Http/Controllers/Api/FinancialRecordController.php:71
* @route '/api/registros/financial-records/{financialRecord}'
*/
const updateForm = (args: { financialRecord: number | { id: number } } | [financialRecord: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Api\FinancialRecordController::update
* @see app/Http/Controllers/Api/FinancialRecordController.php:71
* @route '/api/registros/financial-records/{financialRecord}'
*/
updateForm.put = (args: { financialRecord: number | { id: number } } | [financialRecord: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

update.form = updateForm

/**
* @see \App\Http\Controllers\Api\FinancialRecordController::destroy
* @see app/Http/Controllers/Api/FinancialRecordController.php:85
* @route '/api/registros/financial-records/{financialRecord}'
*/
export const destroy = (args: { financialRecord: number | { id: number } } | [financialRecord: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/api/registros/financial-records/{financialRecord}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Api\FinancialRecordController::destroy
* @see app/Http/Controllers/Api/FinancialRecordController.php:85
* @route '/api/registros/financial-records/{financialRecord}'
*/
destroy.url = (args: { financialRecord: number | { id: number } } | [financialRecord: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { financialRecord: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { financialRecord: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            financialRecord: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        financialRecord: typeof args.financialRecord === 'object'
        ? args.financialRecord.id
        : args.financialRecord,
    }

    return destroy.definition.url
            .replace('{financialRecord}', parsedArgs.financialRecord.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\FinancialRecordController::destroy
* @see app/Http/Controllers/Api/FinancialRecordController.php:85
* @route '/api/registros/financial-records/{financialRecord}'
*/
destroy.delete = (args: { financialRecord: number | { id: number } } | [financialRecord: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

/**
* @see \App\Http\Controllers\Api\FinancialRecordController::destroy
* @see app/Http/Controllers/Api/FinancialRecordController.php:85
* @route '/api/registros/financial-records/{financialRecord}'
*/
const destroyForm = (args: { financialRecord: number | { id: number } } | [financialRecord: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Api\FinancialRecordController::destroy
* @see app/Http/Controllers/Api/FinancialRecordController.php:85
* @route '/api/registros/financial-records/{financialRecord}'
*/
destroyForm.delete = (args: { financialRecord: number | { id: number } } | [financialRecord: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

destroy.form = destroyForm

const FinancialRecordController = { index, show, byDate, clearAll, betweenDates, dailyTotals, restore, store, update, destroy }

export default FinancialRecordController