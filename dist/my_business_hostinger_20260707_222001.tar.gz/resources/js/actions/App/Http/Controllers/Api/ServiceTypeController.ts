import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Api\ServiceTypeController::index
* @see app/Http/Controllers/Api/ServiceTypeController.php:13
* @route '/api/personalizar/service-types'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/api/personalizar/service-types',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\ServiceTypeController::index
* @see app/Http/Controllers/Api/ServiceTypeController.php:13
* @route '/api/personalizar/service-types'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\ServiceTypeController::index
* @see app/Http/Controllers/Api/ServiceTypeController.php:13
* @route '/api/personalizar/service-types'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\ServiceTypeController::index
* @see app/Http/Controllers/Api/ServiceTypeController.php:13
* @route '/api/personalizar/service-types'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Api\ServiceTypeController::index
* @see app/Http/Controllers/Api/ServiceTypeController.php:13
* @route '/api/personalizar/service-types'
*/
const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\ServiceTypeController::index
* @see app/Http/Controllers/Api/ServiceTypeController.php:13
* @route '/api/personalizar/service-types'
*/
indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\ServiceTypeController::index
* @see app/Http/Controllers/Api/ServiceTypeController.php:13
* @route '/api/personalizar/service-types'
*/
indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index.form = indexForm

/**
* @see \App\Http\Controllers\Api\ServiceTypeController::withTrashed
* @see app/Http/Controllers/Api/ServiceTypeController.php:69
* @route '/api/personalizar/service-types/with-trashed'
*/
export const withTrashed = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: withTrashed.url(options),
    method: 'get',
})

withTrashed.definition = {
    methods: ["get","head"],
    url: '/api/personalizar/service-types/with-trashed',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\ServiceTypeController::withTrashed
* @see app/Http/Controllers/Api/ServiceTypeController.php:69
* @route '/api/personalizar/service-types/with-trashed'
*/
withTrashed.url = (options?: RouteQueryOptions) => {
    return withTrashed.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\ServiceTypeController::withTrashed
* @see app/Http/Controllers/Api/ServiceTypeController.php:69
* @route '/api/personalizar/service-types/with-trashed'
*/
withTrashed.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: withTrashed.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\ServiceTypeController::withTrashed
* @see app/Http/Controllers/Api/ServiceTypeController.php:69
* @route '/api/personalizar/service-types/with-trashed'
*/
withTrashed.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: withTrashed.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Api\ServiceTypeController::withTrashed
* @see app/Http/Controllers/Api/ServiceTypeController.php:69
* @route '/api/personalizar/service-types/with-trashed'
*/
const withTrashedForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: withTrashed.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\ServiceTypeController::withTrashed
* @see app/Http/Controllers/Api/ServiceTypeController.php:69
* @route '/api/personalizar/service-types/with-trashed'
*/
withTrashedForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: withTrashed.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\ServiceTypeController::withTrashed
* @see app/Http/Controllers/Api/ServiceTypeController.php:69
* @route '/api/personalizar/service-types/with-trashed'
*/
withTrashedForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: withTrashed.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

withTrashed.form = withTrashedForm

/**
* @see \App\Http\Controllers\Api\ServiceTypeController::show
* @see app/Http/Controllers/Api/ServiceTypeController.php:32
* @route '/api/personalizar/service-types/{serviceType}'
*/
export const show = (args: { serviceType: number | { id: number } } | [serviceType: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/api/personalizar/service-types/{serviceType}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\ServiceTypeController::show
* @see app/Http/Controllers/Api/ServiceTypeController.php:32
* @route '/api/personalizar/service-types/{serviceType}'
*/
show.url = (args: { serviceType: number | { id: number } } | [serviceType: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { serviceType: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { serviceType: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            serviceType: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        serviceType: typeof args.serviceType === 'object'
        ? args.serviceType.id
        : args.serviceType,
    }

    return show.definition.url
            .replace('{serviceType}', parsedArgs.serviceType.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\ServiceTypeController::show
* @see app/Http/Controllers/Api/ServiceTypeController.php:32
* @route '/api/personalizar/service-types/{serviceType}'
*/
show.get = (args: { serviceType: number | { id: number } } | [serviceType: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\ServiceTypeController::show
* @see app/Http/Controllers/Api/ServiceTypeController.php:32
* @route '/api/personalizar/service-types/{serviceType}'
*/
show.head = (args: { serviceType: number | { id: number } } | [serviceType: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Api\ServiceTypeController::show
* @see app/Http/Controllers/Api/ServiceTypeController.php:32
* @route '/api/personalizar/service-types/{serviceType}'
*/
const showForm = (args: { serviceType: number | { id: number } } | [serviceType: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\ServiceTypeController::show
* @see app/Http/Controllers/Api/ServiceTypeController.php:32
* @route '/api/personalizar/service-types/{serviceType}'
*/
showForm.get = (args: { serviceType: number | { id: number } } | [serviceType: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\ServiceTypeController::show
* @see app/Http/Controllers/Api/ServiceTypeController.php:32
* @route '/api/personalizar/service-types/{serviceType}'
*/
showForm.head = (args: { serviceType: number | { id: number } } | [serviceType: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

show.form = showForm

/**
* @see \App\Http\Controllers\Api\ServiceTypeController::restore
* @see app/Http/Controllers/Api/ServiceTypeController.php:79
* @route '/api/personalizar/service-types/{id}/restore'
*/
export const restore = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: restore.url(args, options),
    method: 'post',
})

restore.definition = {
    methods: ["post"],
    url: '/api/personalizar/service-types/{id}/restore',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\ServiceTypeController::restore
* @see app/Http/Controllers/Api/ServiceTypeController.php:79
* @route '/api/personalizar/service-types/{id}/restore'
*/
restore.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    if (Array.isArray(args)) {
        args = {
            id: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        id: args.id,
    }

    return restore.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\ServiceTypeController::restore
* @see app/Http/Controllers/Api/ServiceTypeController.php:79
* @route '/api/personalizar/service-types/{id}/restore'
*/
restore.post = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: restore.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Api\ServiceTypeController::restore
* @see app/Http/Controllers/Api/ServiceTypeController.php:79
* @route '/api/personalizar/service-types/{id}/restore'
*/
const restoreForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: restore.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Api\ServiceTypeController::restore
* @see app/Http/Controllers/Api/ServiceTypeController.php:79
* @route '/api/personalizar/service-types/{id}/restore'
*/
restoreForm.post = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: restore.url(args, options),
    method: 'post',
})

restore.form = restoreForm

/**
* @see \App\Http\Controllers\Api\ServiceTypeController::store
* @see app/Http/Controllers/Api/ServiceTypeController.php:22
* @route '/api/personalizar/service-types'
*/
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/api/personalizar/service-types',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\ServiceTypeController::store
* @see app/Http/Controllers/Api/ServiceTypeController.php:22
* @route '/api/personalizar/service-types'
*/
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\ServiceTypeController::store
* @see app/Http/Controllers/Api/ServiceTypeController.php:22
* @route '/api/personalizar/service-types'
*/
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Api\ServiceTypeController::store
* @see app/Http/Controllers/Api/ServiceTypeController.php:22
* @route '/api/personalizar/service-types'
*/
const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Api\ServiceTypeController::store
* @see app/Http/Controllers/Api/ServiceTypeController.php:22
* @route '/api/personalizar/service-types'
*/
storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

store.form = storeForm

/**
* @see \App\Http\Controllers\Api\ServiceTypeController::update
* @see app/Http/Controllers/Api/ServiceTypeController.php:41
* @route '/api/personalizar/service-types/{serviceType}'
*/
export const update = (args: { serviceType: number | { id: number } } | [serviceType: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/api/personalizar/service-types/{serviceType}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Api\ServiceTypeController::update
* @see app/Http/Controllers/Api/ServiceTypeController.php:41
* @route '/api/personalizar/service-types/{serviceType}'
*/
update.url = (args: { serviceType: number | { id: number } } | [serviceType: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { serviceType: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { serviceType: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            serviceType: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        serviceType: typeof args.serviceType === 'object'
        ? args.serviceType.id
        : args.serviceType,
    }

    return update.definition.url
            .replace('{serviceType}', parsedArgs.serviceType.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\ServiceTypeController::update
* @see app/Http/Controllers/Api/ServiceTypeController.php:41
* @route '/api/personalizar/service-types/{serviceType}'
*/
update.put = (args: { serviceType: number | { id: number } } | [serviceType: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\Api\ServiceTypeController::update
* @see app/Http/Controllers/Api/ServiceTypeController.php:41
* @route '/api/personalizar/service-types/{serviceType}'
*/
const updateForm = (args: { serviceType: number | { id: number } } | [serviceType: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Api\ServiceTypeController::update
* @see app/Http/Controllers/Api/ServiceTypeController.php:41
* @route '/api/personalizar/service-types/{serviceType}'
*/
updateForm.put = (args: { serviceType: number | { id: number } } | [serviceType: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

update.form = updateForm

/**
* @see \App\Http\Controllers\Api\ServiceTypeController::destroy
* @see app/Http/Controllers/Api/ServiceTypeController.php:52
* @route '/api/personalizar/service-types/{serviceType}'
*/
export const destroy = (args: { serviceType: number | { id: number } } | [serviceType: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/api/personalizar/service-types/{serviceType}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Api\ServiceTypeController::destroy
* @see app/Http/Controllers/Api/ServiceTypeController.php:52
* @route '/api/personalizar/service-types/{serviceType}'
*/
destroy.url = (args: { serviceType: number | { id: number } } | [serviceType: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { serviceType: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { serviceType: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            serviceType: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        serviceType: typeof args.serviceType === 'object'
        ? args.serviceType.id
        : args.serviceType,
    }

    return destroy.definition.url
            .replace('{serviceType}', parsedArgs.serviceType.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\ServiceTypeController::destroy
* @see app/Http/Controllers/Api/ServiceTypeController.php:52
* @route '/api/personalizar/service-types/{serviceType}'
*/
destroy.delete = (args: { serviceType: number | { id: number } } | [serviceType: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

/**
* @see \App\Http\Controllers\Api\ServiceTypeController::destroy
* @see app/Http/Controllers/Api/ServiceTypeController.php:52
* @route '/api/personalizar/service-types/{serviceType}'
*/
const destroyForm = (args: { serviceType: number | { id: number } } | [serviceType: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Api\ServiceTypeController::destroy
* @see app/Http/Controllers/Api/ServiceTypeController.php:52
* @route '/api/personalizar/service-types/{serviceType}'
*/
destroyForm.delete = (args: { serviceType: number | { id: number } } | [serviceType: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

destroy.form = destroyForm

const ServiceTypeController = { index, withTrashed, show, restore, store, update, destroy }

export default ServiceTypeController