import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Api\ImportController::logs
* @see app/Http/Controllers/Api/ImportController.php:53
* @route '/api/import-logs'
*/
export const logs = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: logs.url(options),
    method: 'get',
})

logs.definition = {
    methods: ["get","head"],
    url: '/api/import-logs',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\ImportController::logs
* @see app/Http/Controllers/Api/ImportController.php:53
* @route '/api/import-logs'
*/
logs.url = (options?: RouteQueryOptions) => {
    return logs.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\ImportController::logs
* @see app/Http/Controllers/Api/ImportController.php:53
* @route '/api/import-logs'
*/
logs.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: logs.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\ImportController::logs
* @see app/Http/Controllers/Api/ImportController.php:53
* @route '/api/import-logs'
*/
logs.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: logs.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Api\ImportController::logs
* @see app/Http/Controllers/Api/ImportController.php:53
* @route '/api/import-logs'
*/
const logsForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: logs.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\ImportController::logs
* @see app/Http/Controllers/Api/ImportController.php:53
* @route '/api/import-logs'
*/
logsForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: logs.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\ImportController::logs
* @see app/Http/Controllers/Api/ImportController.php:53
* @route '/api/import-logs'
*/
logsForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: logs.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

logs.form = logsForm

/**
* @see \App\Http\Controllers\Api\ImportController::importMethod
* @see app/Http/Controllers/Api/ImportController.php:17
* @route '/api/import'
*/
export const importMethod = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: importMethod.url(options),
    method: 'post',
})

importMethod.definition = {
    methods: ["post"],
    url: '/api/import',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\ImportController::importMethod
* @see app/Http/Controllers/Api/ImportController.php:17
* @route '/api/import'
*/
importMethod.url = (options?: RouteQueryOptions) => {
    return importMethod.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\ImportController::importMethod
* @see app/Http/Controllers/Api/ImportController.php:17
* @route '/api/import'
*/
importMethod.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: importMethod.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Api\ImportController::importMethod
* @see app/Http/Controllers/Api/ImportController.php:17
* @route '/api/import'
*/
const importMethodForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: importMethod.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Api\ImportController::importMethod
* @see app/Http/Controllers/Api/ImportController.php:17
* @route '/api/import'
*/
importMethodForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: importMethod.url(options),
    method: 'post',
})

importMethod.form = importMethodForm

const ImportController = { logs, importMethod, import: importMethod }

export default ImportController