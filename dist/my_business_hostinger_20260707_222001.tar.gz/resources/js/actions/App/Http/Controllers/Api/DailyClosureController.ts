import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Api\DailyClosureController::index
* @see app/Http/Controllers/Api/DailyClosureController.php:16
* @route '/api/registros/daily-closures'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/api/registros/daily-closures',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\DailyClosureController::index
* @see app/Http/Controllers/Api/DailyClosureController.php:16
* @route '/api/registros/daily-closures'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\DailyClosureController::index
* @see app/Http/Controllers/Api/DailyClosureController.php:16
* @route '/api/registros/daily-closures'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\DailyClosureController::index
* @see app/Http/Controllers/Api/DailyClosureController.php:16
* @route '/api/registros/daily-closures'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Api\DailyClosureController::index
* @see app/Http/Controllers/Api/DailyClosureController.php:16
* @route '/api/registros/daily-closures'
*/
const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\DailyClosureController::index
* @see app/Http/Controllers/Api/DailyClosureController.php:16
* @route '/api/registros/daily-closures'
*/
indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\DailyClosureController::index
* @see app/Http/Controllers/Api/DailyClosureController.php:16
* @route '/api/registros/daily-closures'
*/
indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index.form = indexForm

/**
* @see \App\Http\Controllers\Api\DailyClosureController::show
* @see app/Http/Controllers/Api/DailyClosureController.php:28
* @route '/api/registros/daily-closures/{id}'
*/
export const show = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/api/registros/daily-closures/{id}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\DailyClosureController::show
* @see app/Http/Controllers/Api/DailyClosureController.php:28
* @route '/api/registros/daily-closures/{id}'
*/
show.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    if (Array.isArray(args)) {
        args = {
            id: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        id: args.id,
    }

    return show.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\DailyClosureController::show
* @see app/Http/Controllers/Api/DailyClosureController.php:28
* @route '/api/registros/daily-closures/{id}'
*/
show.get = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\DailyClosureController::show
* @see app/Http/Controllers/Api/DailyClosureController.php:28
* @route '/api/registros/daily-closures/{id}'
*/
show.head = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Api\DailyClosureController::show
* @see app/Http/Controllers/Api/DailyClosureController.php:28
* @route '/api/registros/daily-closures/{id}'
*/
const showForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\DailyClosureController::show
* @see app/Http/Controllers/Api/DailyClosureController.php:28
* @route '/api/registros/daily-closures/{id}'
*/
showForm.get = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\DailyClosureController::show
* @see app/Http/Controllers/Api/DailyClosureController.php:28
* @route '/api/registros/daily-closures/{id}'
*/
showForm.head = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

show.form = showForm

/**
* @see \App\Http\Controllers\Api\DailyClosureController::isClosed
* @see app/Http/Controllers/Api/DailyClosureController.php:157
* @route '/api/registros/daily-closures/is-closed/{date}'
*/
export const isClosed = (args: { date: string | number } | [date: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: isClosed.url(args, options),
    method: 'get',
})

isClosed.definition = {
    methods: ["get","head"],
    url: '/api/registros/daily-closures/is-closed/{date}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\DailyClosureController::isClosed
* @see app/Http/Controllers/Api/DailyClosureController.php:157
* @route '/api/registros/daily-closures/is-closed/{date}'
*/
isClosed.url = (args: { date: string | number } | [date: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { date: args }
    }

    if (Array.isArray(args)) {
        args = {
            date: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        date: args.date,
    }

    return isClosed.definition.url
            .replace('{date}', parsedArgs.date.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\DailyClosureController::isClosed
* @see app/Http/Controllers/Api/DailyClosureController.php:157
* @route '/api/registros/daily-closures/is-closed/{date}'
*/
isClosed.get = (args: { date: string | number } | [date: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: isClosed.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\DailyClosureController::isClosed
* @see app/Http/Controllers/Api/DailyClosureController.php:157
* @route '/api/registros/daily-closures/is-closed/{date}'
*/
isClosed.head = (args: { date: string | number } | [date: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: isClosed.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Api\DailyClosureController::isClosed
* @see app/Http/Controllers/Api/DailyClosureController.php:157
* @route '/api/registros/daily-closures/is-closed/{date}'
*/
const isClosedForm = (args: { date: string | number } | [date: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: isClosed.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\DailyClosureController::isClosed
* @see app/Http/Controllers/Api/DailyClosureController.php:157
* @route '/api/registros/daily-closures/is-closed/{date}'
*/
isClosedForm.get = (args: { date: string | number } | [date: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: isClosed.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\DailyClosureController::isClosed
* @see app/Http/Controllers/Api/DailyClosureController.php:157
* @route '/api/registros/daily-closures/is-closed/{date}'
*/
isClosedForm.head = (args: { date: string | number } | [date: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: isClosed.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

isClosed.form = isClosedForm

/**
* @see \App\Http\Controllers\Api\DailyClosureController::store
* @see app/Http/Controllers/Api/DailyClosureController.php:40
* @route '/api/registros/daily-closures'
*/
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/api/registros/daily-closures',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\DailyClosureController::store
* @see app/Http/Controllers/Api/DailyClosureController.php:40
* @route '/api/registros/daily-closures'
*/
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\DailyClosureController::store
* @see app/Http/Controllers/Api/DailyClosureController.php:40
* @route '/api/registros/daily-closures'
*/
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Api\DailyClosureController::store
* @see app/Http/Controllers/Api/DailyClosureController.php:40
* @route '/api/registros/daily-closures'
*/
const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Api\DailyClosureController::store
* @see app/Http/Controllers/Api/DailyClosureController.php:40
* @route '/api/registros/daily-closures'
*/
storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

store.form = storeForm

/**
* @see \App\Http\Controllers\Api\DailyClosureController::update
* @see app/Http/Controllers/Api/DailyClosureController.php:0
* @route '/api/registros/daily-closures/{id}'
*/
export const update = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/api/registros/daily-closures/{id}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Api\DailyClosureController::update
* @see app/Http/Controllers/Api/DailyClosureController.php:0
* @route '/api/registros/daily-closures/{id}'
*/
update.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    if (Array.isArray(args)) {
        args = {
            id: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        id: args.id,
    }

    return update.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\DailyClosureController::update
* @see app/Http/Controllers/Api/DailyClosureController.php:0
* @route '/api/registros/daily-closures/{id}'
*/
update.put = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\Api\DailyClosureController::update
* @see app/Http/Controllers/Api/DailyClosureController.php:0
* @route '/api/registros/daily-closures/{id}'
*/
const updateForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Api\DailyClosureController::update
* @see app/Http/Controllers/Api/DailyClosureController.php:0
* @route '/api/registros/daily-closures/{id}'
*/
updateForm.put = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

update.form = updateForm

/**
* @see \App\Http\Controllers\Api\DailyClosureController::destroy
* @see app/Http/Controllers/Api/DailyClosureController.php:0
* @route '/api/registros/daily-closures/{id}'
*/
export const destroy = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/api/registros/daily-closures/{id}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Api\DailyClosureController::destroy
* @see app/Http/Controllers/Api/DailyClosureController.php:0
* @route '/api/registros/daily-closures/{id}'
*/
destroy.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    if (Array.isArray(args)) {
        args = {
            id: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        id: args.id,
    }

    return destroy.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\DailyClosureController::destroy
* @see app/Http/Controllers/Api/DailyClosureController.php:0
* @route '/api/registros/daily-closures/{id}'
*/
destroy.delete = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

/**
* @see \App\Http\Controllers\Api\DailyClosureController::destroy
* @see app/Http/Controllers/Api/DailyClosureController.php:0
* @route '/api/registros/daily-closures/{id}'
*/
const destroyForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Api\DailyClosureController::destroy
* @see app/Http/Controllers/Api/DailyClosureController.php:0
* @route '/api/registros/daily-closures/{id}'
*/
destroyForm.delete = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

destroy.form = destroyForm

/**
* @see \App\Http\Controllers\Api\DailyClosureController::reopen
* @see app/Http/Controllers/Api/DailyClosureController.php:99
* @route '/api/registros/daily-closures/reopen/{dailyClosure}'
*/
export const reopen = (args: { dailyClosure: number | { id: number } } | [dailyClosure: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: reopen.url(args, options),
    method: 'post',
})

reopen.definition = {
    methods: ["post"],
    url: '/api/registros/daily-closures/reopen/{dailyClosure}',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\DailyClosureController::reopen
* @see app/Http/Controllers/Api/DailyClosureController.php:99
* @route '/api/registros/daily-closures/reopen/{dailyClosure}'
*/
reopen.url = (args: { dailyClosure: number | { id: number } } | [dailyClosure: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { dailyClosure: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { dailyClosure: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            dailyClosure: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        dailyClosure: typeof args.dailyClosure === 'object'
        ? args.dailyClosure.id
        : args.dailyClosure,
    }

    return reopen.definition.url
            .replace('{dailyClosure}', parsedArgs.dailyClosure.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\DailyClosureController::reopen
* @see app/Http/Controllers/Api/DailyClosureController.php:99
* @route '/api/registros/daily-closures/reopen/{dailyClosure}'
*/
reopen.post = (args: { dailyClosure: number | { id: number } } | [dailyClosure: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: reopen.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Api\DailyClosureController::reopen
* @see app/Http/Controllers/Api/DailyClosureController.php:99
* @route '/api/registros/daily-closures/reopen/{dailyClosure}'
*/
const reopenForm = (args: { dailyClosure: number | { id: number } } | [dailyClosure: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: reopen.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Api\DailyClosureController::reopen
* @see app/Http/Controllers/Api/DailyClosureController.php:99
* @route '/api/registros/daily-closures/reopen/{dailyClosure}'
*/
reopenForm.post = (args: { dailyClosure: number | { id: number } } | [dailyClosure: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: reopen.url(args, options),
    method: 'post',
})

reopen.form = reopenForm

/**
* @see \App\Http\Controllers\Api\DailyClosureController::summary
* @see app/Http/Controllers/Api/DailyClosureController.php:123
* @route '/api/registros/daily-closures/summary'
*/
export const summary = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: summary.url(options),
    method: 'post',
})

summary.definition = {
    methods: ["post"],
    url: '/api/registros/daily-closures/summary',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\DailyClosureController::summary
* @see app/Http/Controllers/Api/DailyClosureController.php:123
* @route '/api/registros/daily-closures/summary'
*/
summary.url = (options?: RouteQueryOptions) => {
    return summary.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\DailyClosureController::summary
* @see app/Http/Controllers/Api/DailyClosureController.php:123
* @route '/api/registros/daily-closures/summary'
*/
summary.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: summary.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Api\DailyClosureController::summary
* @see app/Http/Controllers/Api/DailyClosureController.php:123
* @route '/api/registros/daily-closures/summary'
*/
const summaryForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: summary.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Api\DailyClosureController::summary
* @see app/Http/Controllers/Api/DailyClosureController.php:123
* @route '/api/registros/daily-closures/summary'
*/
summaryForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: summary.url(options),
    method: 'post',
})

summary.form = summaryForm

const DailyClosureController = { index, show, isClosed, store, update, destroy, reopen, summary }

export default DailyClosureController