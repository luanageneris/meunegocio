import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Api\CommissionController::index
* @see app/Http/Controllers/Api/CommissionController.php:17
* @route '/api/registros/commissions'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/api/registros/commissions',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\CommissionController::index
* @see app/Http/Controllers/Api/CommissionController.php:17
* @route '/api/registros/commissions'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\CommissionController::index
* @see app/Http/Controllers/Api/CommissionController.php:17
* @route '/api/registros/commissions'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\CommissionController::index
* @see app/Http/Controllers/Api/CommissionController.php:17
* @route '/api/registros/commissions'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Api\CommissionController::index
* @see app/Http/Controllers/Api/CommissionController.php:17
* @route '/api/registros/commissions'
*/
const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\CommissionController::index
* @see app/Http/Controllers/Api/CommissionController.php:17
* @route '/api/registros/commissions'
*/
indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\CommissionController::index
* @see app/Http/Controllers/Api/CommissionController.php:17
* @route '/api/registros/commissions'
*/
indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index.form = indexForm

/**
* @see \App\Http\Controllers\Api\CommissionController::show
* @see app/Http/Controllers/Api/CommissionController.php:40
* @route '/api/registros/commissions/{id}'
*/
export const show = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/api/registros/commissions/{id}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\CommissionController::show
* @see app/Http/Controllers/Api/CommissionController.php:40
* @route '/api/registros/commissions/{id}'
*/
show.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    if (Array.isArray(args)) {
        args = {
            id: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        id: args.id,
    }

    return show.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\CommissionController::show
* @see app/Http/Controllers/Api/CommissionController.php:40
* @route '/api/registros/commissions/{id}'
*/
show.get = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\CommissionController::show
* @see app/Http/Controllers/Api/CommissionController.php:40
* @route '/api/registros/commissions/{id}'
*/
show.head = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Api\CommissionController::show
* @see app/Http/Controllers/Api/CommissionController.php:40
* @route '/api/registros/commissions/{id}'
*/
const showForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\CommissionController::show
* @see app/Http/Controllers/Api/CommissionController.php:40
* @route '/api/registros/commissions/{id}'
*/
showForm.get = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\CommissionController::show
* @see app/Http/Controllers/Api/CommissionController.php:40
* @route '/api/registros/commissions/{id}'
*/
showForm.head = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

show.form = showForm

/**
* @see \App\Http\Controllers\Api\CommissionController::unpaidCommissions
* @see app/Http/Controllers/Api/CommissionController.php:157
* @route '/api/registros/commissions/collaborator/{collaboratorId}/unpaid'
*/
export const unpaidCommissions = (args: { collaboratorId: string | number } | [collaboratorId: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: unpaidCommissions.url(args, options),
    method: 'get',
})

unpaidCommissions.definition = {
    methods: ["get","head"],
    url: '/api/registros/commissions/collaborator/{collaboratorId}/unpaid',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\CommissionController::unpaidCommissions
* @see app/Http/Controllers/Api/CommissionController.php:157
* @route '/api/registros/commissions/collaborator/{collaboratorId}/unpaid'
*/
unpaidCommissions.url = (args: { collaboratorId: string | number } | [collaboratorId: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { collaboratorId: args }
    }

    if (Array.isArray(args)) {
        args = {
            collaboratorId: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        collaboratorId: args.collaboratorId,
    }

    return unpaidCommissions.definition.url
            .replace('{collaboratorId}', parsedArgs.collaboratorId.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\CommissionController::unpaidCommissions
* @see app/Http/Controllers/Api/CommissionController.php:157
* @route '/api/registros/commissions/collaborator/{collaboratorId}/unpaid'
*/
unpaidCommissions.get = (args: { collaboratorId: string | number } | [collaboratorId: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: unpaidCommissions.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\CommissionController::unpaidCommissions
* @see app/Http/Controllers/Api/CommissionController.php:157
* @route '/api/registros/commissions/collaborator/{collaboratorId}/unpaid'
*/
unpaidCommissions.head = (args: { collaboratorId: string | number } | [collaboratorId: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: unpaidCommissions.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Api\CommissionController::unpaidCommissions
* @see app/Http/Controllers/Api/CommissionController.php:157
* @route '/api/registros/commissions/collaborator/{collaboratorId}/unpaid'
*/
const unpaidCommissionsForm = (args: { collaboratorId: string | number } | [collaboratorId: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: unpaidCommissions.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\CommissionController::unpaidCommissions
* @see app/Http/Controllers/Api/CommissionController.php:157
* @route '/api/registros/commissions/collaborator/{collaboratorId}/unpaid'
*/
unpaidCommissionsForm.get = (args: { collaboratorId: string | number } | [collaboratorId: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: unpaidCommissions.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\CommissionController::unpaidCommissions
* @see app/Http/Controllers/Api/CommissionController.php:157
* @route '/api/registros/commissions/collaborator/{collaboratorId}/unpaid'
*/
unpaidCommissionsForm.head = (args: { collaboratorId: string | number } | [collaboratorId: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: unpaidCommissions.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

unpaidCommissions.form = unpaidCommissionsForm

/**
* @see \App\Http\Controllers\Api\CommissionController::collaboratorCommissions
* @see app/Http/Controllers/Api/CommissionController.php:134
* @route '/api/registros/commissions/collaborator/{collaboratorId}'
*/
export const collaboratorCommissions = (args: { collaboratorId: string | number } | [collaboratorId: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: collaboratorCommissions.url(args, options),
    method: 'get',
})

collaboratorCommissions.definition = {
    methods: ["get","head"],
    url: '/api/registros/commissions/collaborator/{collaboratorId}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\CommissionController::collaboratorCommissions
* @see app/Http/Controllers/Api/CommissionController.php:134
* @route '/api/registros/commissions/collaborator/{collaboratorId}'
*/
collaboratorCommissions.url = (args: { collaboratorId: string | number } | [collaboratorId: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { collaboratorId: args }
    }

    if (Array.isArray(args)) {
        args = {
            collaboratorId: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        collaboratorId: args.collaboratorId,
    }

    return collaboratorCommissions.definition.url
            .replace('{collaboratorId}', parsedArgs.collaboratorId.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\CommissionController::collaboratorCommissions
* @see app/Http/Controllers/Api/CommissionController.php:134
* @route '/api/registros/commissions/collaborator/{collaboratorId}'
*/
collaboratorCommissions.get = (args: { collaboratorId: string | number } | [collaboratorId: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: collaboratorCommissions.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\CommissionController::collaboratorCommissions
* @see app/Http/Controllers/Api/CommissionController.php:134
* @route '/api/registros/commissions/collaborator/{collaboratorId}'
*/
collaboratorCommissions.head = (args: { collaboratorId: string | number } | [collaboratorId: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: collaboratorCommissions.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Api\CommissionController::collaboratorCommissions
* @see app/Http/Controllers/Api/CommissionController.php:134
* @route '/api/registros/commissions/collaborator/{collaboratorId}'
*/
const collaboratorCommissionsForm = (args: { collaboratorId: string | number } | [collaboratorId: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: collaboratorCommissions.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\CommissionController::collaboratorCommissions
* @see app/Http/Controllers/Api/CommissionController.php:134
* @route '/api/registros/commissions/collaborator/{collaboratorId}'
*/
collaboratorCommissionsForm.get = (args: { collaboratorId: string | number } | [collaboratorId: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: collaboratorCommissions.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\CommissionController::collaboratorCommissions
* @see app/Http/Controllers/Api/CommissionController.php:134
* @route '/api/registros/commissions/collaborator/{collaboratorId}'
*/
collaboratorCommissionsForm.head = (args: { collaboratorId: string | number } | [collaboratorId: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: collaboratorCommissions.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

collaboratorCommissions.form = collaboratorCommissionsForm

/**
* @see \App\Http\Controllers\Api\CommissionController::generateFromDate
* @see app/Http/Controllers/Api/CommissionController.php:84
* @route '/api/registros/commissions/generate-from-date'
*/
export const generateFromDate = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: generateFromDate.url(options),
    method: 'post',
})

generateFromDate.definition = {
    methods: ["post"],
    url: '/api/registros/commissions/generate-from-date',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\CommissionController::generateFromDate
* @see app/Http/Controllers/Api/CommissionController.php:84
* @route '/api/registros/commissions/generate-from-date'
*/
generateFromDate.url = (options?: RouteQueryOptions) => {
    return generateFromDate.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\CommissionController::generateFromDate
* @see app/Http/Controllers/Api/CommissionController.php:84
* @route '/api/registros/commissions/generate-from-date'
*/
generateFromDate.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: generateFromDate.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Api\CommissionController::generateFromDate
* @see app/Http/Controllers/Api/CommissionController.php:84
* @route '/api/registros/commissions/generate-from-date'
*/
const generateFromDateForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: generateFromDate.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Api\CommissionController::generateFromDate
* @see app/Http/Controllers/Api/CommissionController.php:84
* @route '/api/registros/commissions/generate-from-date'
*/
generateFromDateForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: generateFromDate.url(options),
    method: 'post',
})

generateFromDate.form = generateFromDateForm

/**
* @see \App\Http\Controllers\Api\CommissionController::markAsPaid
* @see app/Http/Controllers/Api/CommissionController.php:177
* @route '/api/registros/commissions/mark-as-paid'
*/
export const markAsPaid = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: markAsPaid.url(options),
    method: 'post',
})

markAsPaid.definition = {
    methods: ["post"],
    url: '/api/registros/commissions/mark-as-paid',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\CommissionController::markAsPaid
* @see app/Http/Controllers/Api/CommissionController.php:177
* @route '/api/registros/commissions/mark-as-paid'
*/
markAsPaid.url = (options?: RouteQueryOptions) => {
    return markAsPaid.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\CommissionController::markAsPaid
* @see app/Http/Controllers/Api/CommissionController.php:177
* @route '/api/registros/commissions/mark-as-paid'
*/
markAsPaid.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: markAsPaid.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Api\CommissionController::markAsPaid
* @see app/Http/Controllers/Api/CommissionController.php:177
* @route '/api/registros/commissions/mark-as-paid'
*/
const markAsPaidForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: markAsPaid.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Api\CommissionController::markAsPaid
* @see app/Http/Controllers/Api/CommissionController.php:177
* @route '/api/registros/commissions/mark-as-paid'
*/
markAsPaidForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: markAsPaid.url(options),
    method: 'post',
})

markAsPaid.form = markAsPaidForm

/**
* @see \App\Http\Controllers\Api\CommissionController::summaryByCollaborator
* @see app/Http/Controllers/Api/CommissionController.php:202
* @route '/api/registros/commissions/summary-by-collaborator'
*/
export const summaryByCollaborator = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: summaryByCollaborator.url(options),
    method: 'post',
})

summaryByCollaborator.definition = {
    methods: ["post"],
    url: '/api/registros/commissions/summary-by-collaborator',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\CommissionController::summaryByCollaborator
* @see app/Http/Controllers/Api/CommissionController.php:202
* @route '/api/registros/commissions/summary-by-collaborator'
*/
summaryByCollaborator.url = (options?: RouteQueryOptions) => {
    return summaryByCollaborator.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\CommissionController::summaryByCollaborator
* @see app/Http/Controllers/Api/CommissionController.php:202
* @route '/api/registros/commissions/summary-by-collaborator'
*/
summaryByCollaborator.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: summaryByCollaborator.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Api\CommissionController::summaryByCollaborator
* @see app/Http/Controllers/Api/CommissionController.php:202
* @route '/api/registros/commissions/summary-by-collaborator'
*/
const summaryByCollaboratorForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: summaryByCollaborator.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Api\CommissionController::summaryByCollaborator
* @see app/Http/Controllers/Api/CommissionController.php:202
* @route '/api/registros/commissions/summary-by-collaborator'
*/
summaryByCollaboratorForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: summaryByCollaborator.url(options),
    method: 'post',
})

summaryByCollaborator.form = summaryByCollaboratorForm

/**
* @see \App\Http\Controllers\Api\CommissionController::summaryByMonth
* @see app/Http/Controllers/Api/CommissionController.php:231
* @route '/api/registros/commissions/summary-by-month'
*/
export const summaryByMonth = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: summaryByMonth.url(options),
    method: 'post',
})

summaryByMonth.definition = {
    methods: ["post"],
    url: '/api/registros/commissions/summary-by-month',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\CommissionController::summaryByMonth
* @see app/Http/Controllers/Api/CommissionController.php:231
* @route '/api/registros/commissions/summary-by-month'
*/
summaryByMonth.url = (options?: RouteQueryOptions) => {
    return summaryByMonth.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\CommissionController::summaryByMonth
* @see app/Http/Controllers/Api/CommissionController.php:231
* @route '/api/registros/commissions/summary-by-month'
*/
summaryByMonth.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: summaryByMonth.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Api\CommissionController::summaryByMonth
* @see app/Http/Controllers/Api/CommissionController.php:231
* @route '/api/registros/commissions/summary-by-month'
*/
const summaryByMonthForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: summaryByMonth.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Api\CommissionController::summaryByMonth
* @see app/Http/Controllers/Api/CommissionController.php:231
* @route '/api/registros/commissions/summary-by-month'
*/
summaryByMonthForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: summaryByMonth.url(options),
    method: 'post',
})

summaryByMonth.form = summaryByMonthForm

/**
* @see \App\Http\Controllers\Api\CommissionController::store
* @see app/Http/Controllers/Api/CommissionController.php:30
* @route '/api/registros/commissions'
*/
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/api/registros/commissions',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\CommissionController::store
* @see app/Http/Controllers/Api/CommissionController.php:30
* @route '/api/registros/commissions'
*/
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\CommissionController::store
* @see app/Http/Controllers/Api/CommissionController.php:30
* @route '/api/registros/commissions'
*/
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Api\CommissionController::store
* @see app/Http/Controllers/Api/CommissionController.php:30
* @route '/api/registros/commissions'
*/
const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Api\CommissionController::store
* @see app/Http/Controllers/Api/CommissionController.php:30
* @route '/api/registros/commissions'
*/
storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

store.form = storeForm

/**
* @see \App\Http\Controllers\Api\CommissionController::update
* @see app/Http/Controllers/Api/CommissionController.php:52
* @route '/api/registros/commissions/{id}'
*/
export const update = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/api/registros/commissions/{id}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Api\CommissionController::update
* @see app/Http/Controllers/Api/CommissionController.php:52
* @route '/api/registros/commissions/{id}'
*/
update.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    if (Array.isArray(args)) {
        args = {
            id: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        id: args.id,
    }

    return update.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\CommissionController::update
* @see app/Http/Controllers/Api/CommissionController.php:52
* @route '/api/registros/commissions/{id}'
*/
update.put = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\Api\CommissionController::update
* @see app/Http/Controllers/Api/CommissionController.php:52
* @route '/api/registros/commissions/{id}'
*/
const updateForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Api\CommissionController::update
* @see app/Http/Controllers/Api/CommissionController.php:52
* @route '/api/registros/commissions/{id}'
*/
updateForm.put = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

update.form = updateForm

/**
* @see \App\Http\Controllers\Api\CommissionController::destroy
* @see app/Http/Controllers/Api/CommissionController.php:66
* @route '/api/registros/commissions/{id}'
*/
export const destroy = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/api/registros/commissions/{id}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Api\CommissionController::destroy
* @see app/Http/Controllers/Api/CommissionController.php:66
* @route '/api/registros/commissions/{id}'
*/
destroy.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    if (Array.isArray(args)) {
        args = {
            id: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        id: args.id,
    }

    return destroy.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\CommissionController::destroy
* @see app/Http/Controllers/Api/CommissionController.php:66
* @route '/api/registros/commissions/{id}'
*/
destroy.delete = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

/**
* @see \App\Http\Controllers\Api\CommissionController::destroy
* @see app/Http/Controllers/Api/CommissionController.php:66
* @route '/api/registros/commissions/{id}'
*/
const destroyForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Api\CommissionController::destroy
* @see app/Http/Controllers/Api/CommissionController.php:66
* @route '/api/registros/commissions/{id}'
*/
destroyForm.delete = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

destroy.form = destroyForm

const CommissionController = { index, show, unpaidCommissions, collaboratorCommissions, generateFromDate, markAsPaid, summaryByCollaborator, summaryByMonth, store, update, destroy }

export default CommissionController