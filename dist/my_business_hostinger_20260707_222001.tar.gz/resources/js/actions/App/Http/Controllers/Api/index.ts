import AuthController from './AuthController'
import HistoryController from './HistoryController'
import DashboardController from './DashboardController'
import CompanyController from './CompanyController'
import CollaboratorController from './CollaboratorController'
import EntryTypeController from './EntryTypeController'
import ExitTypeController from './ExitTypeController'
import ServiceTypeController from './ServiceTypeController'
import FinancialRecordController from './FinancialRecordController'
import WorkShiftController from './WorkShiftController'
import DailyClosureController from './DailyClosureController'
import CommissionController from './CommissionController'
import BalanceController from './BalanceController'
import ImportController from './ImportController'
import SupportController from './SupportController'

const Api = {
    AuthController: Object.assign(AuthController, AuthController),
    HistoryController: Object.assign(HistoryController, HistoryController),
    DashboardController: Object.assign(DashboardController, DashboardController),
    CompanyController: Object.assign(CompanyController, CompanyController),
    CollaboratorController: Object.assign(CollaboratorController, CollaboratorController),
    EntryTypeController: Object.assign(EntryTypeController, EntryTypeController),
    ExitTypeController: Object.assign(ExitTypeController, ExitTypeController),
    ServiceTypeController: Object.assign(ServiceTypeController, ServiceTypeController),
    FinancialRecordController: Object.assign(FinancialRecordController, FinancialRecordController),
    WorkShiftController: Object.assign(WorkShiftController, WorkShiftController),
    DailyClosureController: Object.assign(DailyClosureController, DailyClosureController),
    CommissionController: Object.assign(CommissionController, CommissionController),
    BalanceController: Object.assign(BalanceController, BalanceController),
    ImportController: Object.assign(ImportController, ImportController),
    SupportController: Object.assign(SupportController, SupportController),
}

export default Api