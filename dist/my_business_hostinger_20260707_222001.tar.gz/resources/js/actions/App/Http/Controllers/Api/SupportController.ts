import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Api\SupportController::send
* @see app/Http/Controllers/Api/SupportController.php:15
* @route '/api/support'
*/
export const send = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: send.url(options),
    method: 'post',
})

send.definition = {
    methods: ["post"],
    url: '/api/support',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\SupportController::send
* @see app/Http/Controllers/Api/SupportController.php:15
* @route '/api/support'
*/
send.url = (options?: RouteQueryOptions) => {
    return send.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\SupportController::send
* @see app/Http/Controllers/Api/SupportController.php:15
* @route '/api/support'
*/
send.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: send.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Api\SupportController::send
* @see app/Http/Controllers/Api/SupportController.php:15
* @route '/api/support'
*/
const sendForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: send.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Api\SupportController::send
* @see app/Http/Controllers/Api/SupportController.php:15
* @route '/api/support'
*/
sendForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: send.url(options),
    method: 'post',
})

send.form = sendForm

const SupportController = { send }

export default SupportController