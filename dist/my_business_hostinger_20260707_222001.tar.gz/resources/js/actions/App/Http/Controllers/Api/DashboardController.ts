import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Api\DashboardController::summary
* @see app/Http/Controllers/Api/DashboardController.php:10
* @route '/api/dashboard/summary'
*/
export const summary = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: summary.url(options),
    method: 'get',
})

summary.definition = {
    methods: ["get","head"],
    url: '/api/dashboard/summary',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\DashboardController::summary
* @see app/Http/Controllers/Api/DashboardController.php:10
* @route '/api/dashboard/summary'
*/
summary.url = (options?: RouteQueryOptions) => {
    return summary.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\DashboardController::summary
* @see app/Http/Controllers/Api/DashboardController.php:10
* @route '/api/dashboard/summary'
*/
summary.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: summary.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\DashboardController::summary
* @see app/Http/Controllers/Api/DashboardController.php:10
* @route '/api/dashboard/summary'
*/
summary.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: summary.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Api\DashboardController::summary
* @see app/Http/Controllers/Api/DashboardController.php:10
* @route '/api/dashboard/summary'
*/
const summaryForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: summary.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\DashboardController::summary
* @see app/Http/Controllers/Api/DashboardController.php:10
* @route '/api/dashboard/summary'
*/
summaryForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: summary.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\DashboardController::summary
* @see app/Http/Controllers/Api/DashboardController.php:10
* @route '/api/dashboard/summary'
*/
summaryForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: summary.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

summary.form = summaryForm

/**
* @see \App\Http\Controllers\Api\DashboardController::commissionsByCollaborator
* @see app/Http/Controllers/Api/DashboardController.php:15
* @route '/api/dashboard/commissions-by-collaborator'
*/
export const commissionsByCollaborator = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: commissionsByCollaborator.url(options),
    method: 'get',
})

commissionsByCollaborator.definition = {
    methods: ["get","head"],
    url: '/api/dashboard/commissions-by-collaborator',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\DashboardController::commissionsByCollaborator
* @see app/Http/Controllers/Api/DashboardController.php:15
* @route '/api/dashboard/commissions-by-collaborator'
*/
commissionsByCollaborator.url = (options?: RouteQueryOptions) => {
    return commissionsByCollaborator.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\DashboardController::commissionsByCollaborator
* @see app/Http/Controllers/Api/DashboardController.php:15
* @route '/api/dashboard/commissions-by-collaborator'
*/
commissionsByCollaborator.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: commissionsByCollaborator.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\DashboardController::commissionsByCollaborator
* @see app/Http/Controllers/Api/DashboardController.php:15
* @route '/api/dashboard/commissions-by-collaborator'
*/
commissionsByCollaborator.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: commissionsByCollaborator.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Api\DashboardController::commissionsByCollaborator
* @see app/Http/Controllers/Api/DashboardController.php:15
* @route '/api/dashboard/commissions-by-collaborator'
*/
const commissionsByCollaboratorForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: commissionsByCollaborator.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\DashboardController::commissionsByCollaborator
* @see app/Http/Controllers/Api/DashboardController.php:15
* @route '/api/dashboard/commissions-by-collaborator'
*/
commissionsByCollaboratorForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: commissionsByCollaborator.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\DashboardController::commissionsByCollaborator
* @see app/Http/Controllers/Api/DashboardController.php:15
* @route '/api/dashboard/commissions-by-collaborator'
*/
commissionsByCollaboratorForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: commissionsByCollaborator.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

commissionsByCollaborator.form = commissionsByCollaboratorForm

/**
* @see \App\Http\Controllers\Api\DashboardController::topProfitableDays
* @see app/Http/Controllers/Api/DashboardController.php:20
* @route '/api/dashboard/top-profitable-days'
*/
export const topProfitableDays = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: topProfitableDays.url(options),
    method: 'get',
})

topProfitableDays.definition = {
    methods: ["get","head"],
    url: '/api/dashboard/top-profitable-days',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\DashboardController::topProfitableDays
* @see app/Http/Controllers/Api/DashboardController.php:20
* @route '/api/dashboard/top-profitable-days'
*/
topProfitableDays.url = (options?: RouteQueryOptions) => {
    return topProfitableDays.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\DashboardController::topProfitableDays
* @see app/Http/Controllers/Api/DashboardController.php:20
* @route '/api/dashboard/top-profitable-days'
*/
topProfitableDays.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: topProfitableDays.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\DashboardController::topProfitableDays
* @see app/Http/Controllers/Api/DashboardController.php:20
* @route '/api/dashboard/top-profitable-days'
*/
topProfitableDays.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: topProfitableDays.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Api\DashboardController::topProfitableDays
* @see app/Http/Controllers/Api/DashboardController.php:20
* @route '/api/dashboard/top-profitable-days'
*/
const topProfitableDaysForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: topProfitableDays.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\DashboardController::topProfitableDays
* @see app/Http/Controllers/Api/DashboardController.php:20
* @route '/api/dashboard/top-profitable-days'
*/
topProfitableDaysForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: topProfitableDays.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\DashboardController::topProfitableDays
* @see app/Http/Controllers/Api/DashboardController.php:20
* @route '/api/dashboard/top-profitable-days'
*/
topProfitableDaysForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: topProfitableDays.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

topProfitableDays.form = topProfitableDaysForm

/**
* @see \App\Http\Controllers\Api\DashboardController::entriesExits
* @see app/Http/Controllers/Api/DashboardController.php:25
* @route '/api/dashboard/entries-exits'
*/
export const entriesExits = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: entriesExits.url(options),
    method: 'get',
})

entriesExits.definition = {
    methods: ["get","head"],
    url: '/api/dashboard/entries-exits',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\DashboardController::entriesExits
* @see app/Http/Controllers/Api/DashboardController.php:25
* @route '/api/dashboard/entries-exits'
*/
entriesExits.url = (options?: RouteQueryOptions) => {
    return entriesExits.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\DashboardController::entriesExits
* @see app/Http/Controllers/Api/DashboardController.php:25
* @route '/api/dashboard/entries-exits'
*/
entriesExits.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: entriesExits.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\DashboardController::entriesExits
* @see app/Http/Controllers/Api/DashboardController.php:25
* @route '/api/dashboard/entries-exits'
*/
entriesExits.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: entriesExits.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Api\DashboardController::entriesExits
* @see app/Http/Controllers/Api/DashboardController.php:25
* @route '/api/dashboard/entries-exits'
*/
const entriesExitsForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: entriesExits.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\DashboardController::entriesExits
* @see app/Http/Controllers/Api/DashboardController.php:25
* @route '/api/dashboard/entries-exits'
*/
entriesExitsForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: entriesExits.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\DashboardController::entriesExits
* @see app/Http/Controllers/Api/DashboardController.php:25
* @route '/api/dashboard/entries-exits'
*/
entriesExitsForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: entriesExits.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

entriesExits.form = entriesExitsForm

const DashboardController = { summary, commissionsByCollaborator, topProfitableDays, entriesExits }

export default DashboardController