import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Api\WorkShiftController::index
* @see app/Http/Controllers/Api/WorkShiftController.php:15
* @route '/api/registros/work-shifts'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/api/registros/work-shifts',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\WorkShiftController::index
* @see app/Http/Controllers/Api/WorkShiftController.php:15
* @route '/api/registros/work-shifts'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\WorkShiftController::index
* @see app/Http/Controllers/Api/WorkShiftController.php:15
* @route '/api/registros/work-shifts'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\WorkShiftController::index
* @see app/Http/Controllers/Api/WorkShiftController.php:15
* @route '/api/registros/work-shifts'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Api\WorkShiftController::index
* @see app/Http/Controllers/Api/WorkShiftController.php:15
* @route '/api/registros/work-shifts'
*/
const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\WorkShiftController::index
* @see app/Http/Controllers/Api/WorkShiftController.php:15
* @route '/api/registros/work-shifts'
*/
indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\WorkShiftController::index
* @see app/Http/Controllers/Api/WorkShiftController.php:15
* @route '/api/registros/work-shifts'
*/
indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index.form = indexForm

/**
* @see \App\Http\Controllers\Api\WorkShiftController::show
* @see app/Http/Controllers/Api/WorkShiftController.php:52
* @route '/api/registros/work-shifts/{id}'
*/
export const show = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/api/registros/work-shifts/{id}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\WorkShiftController::show
* @see app/Http/Controllers/Api/WorkShiftController.php:52
* @route '/api/registros/work-shifts/{id}'
*/
show.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    if (Array.isArray(args)) {
        args = {
            id: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        id: args.id,
    }

    return show.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\WorkShiftController::show
* @see app/Http/Controllers/Api/WorkShiftController.php:52
* @route '/api/registros/work-shifts/{id}'
*/
show.get = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\WorkShiftController::show
* @see app/Http/Controllers/Api/WorkShiftController.php:52
* @route '/api/registros/work-shifts/{id}'
*/
show.head = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Api\WorkShiftController::show
* @see app/Http/Controllers/Api/WorkShiftController.php:52
* @route '/api/registros/work-shifts/{id}'
*/
const showForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\WorkShiftController::show
* @see app/Http/Controllers/Api/WorkShiftController.php:52
* @route '/api/registros/work-shifts/{id}'
*/
showForm.get = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\WorkShiftController::show
* @see app/Http/Controllers/Api/WorkShiftController.php:52
* @route '/api/registros/work-shifts/{id}'
*/
showForm.head = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

show.form = showForm

/**
* @see \App\Http\Controllers\Api\WorkShiftController::byDate
* @see app/Http/Controllers/Api/WorkShiftController.php:111
* @route '/api/registros/work-shifts/by-date/{date}'
*/
export const byDate = (args: { date: string | number } | [date: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: byDate.url(args, options),
    method: 'get',
})

byDate.definition = {
    methods: ["get","head"],
    url: '/api/registros/work-shifts/by-date/{date}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\WorkShiftController::byDate
* @see app/Http/Controllers/Api/WorkShiftController.php:111
* @route '/api/registros/work-shifts/by-date/{date}'
*/
byDate.url = (args: { date: string | number } | [date: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { date: args }
    }

    if (Array.isArray(args)) {
        args = {
            date: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        date: args.date,
    }

    return byDate.definition.url
            .replace('{date}', parsedArgs.date.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\WorkShiftController::byDate
* @see app/Http/Controllers/Api/WorkShiftController.php:111
* @route '/api/registros/work-shifts/by-date/{date}'
*/
byDate.get = (args: { date: string | number } | [date: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: byDate.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\WorkShiftController::byDate
* @see app/Http/Controllers/Api/WorkShiftController.php:111
* @route '/api/registros/work-shifts/by-date/{date}'
*/
byDate.head = (args: { date: string | number } | [date: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: byDate.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Api\WorkShiftController::byDate
* @see app/Http/Controllers/Api/WorkShiftController.php:111
* @route '/api/registros/work-shifts/by-date/{date}'
*/
const byDateForm = (args: { date: string | number } | [date: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: byDate.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\WorkShiftController::byDate
* @see app/Http/Controllers/Api/WorkShiftController.php:111
* @route '/api/registros/work-shifts/by-date/{date}'
*/
byDateForm.get = (args: { date: string | number } | [date: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: byDate.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\WorkShiftController::byDate
* @see app/Http/Controllers/Api/WorkShiftController.php:111
* @route '/api/registros/work-shifts/by-date/{date}'
*/
byDateForm.head = (args: { date: string | number } | [date: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: byDate.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

byDate.form = byDateForm

/**
* @see \App\Http\Controllers\Api\WorkShiftController::collaboratorShifts
* @see app/Http/Controllers/Api/WorkShiftController.php:125
* @route '/api/registros/work-shifts/collaborator/{collaboratorId}'
*/
export const collaboratorShifts = (args: { collaboratorId: string | number } | [collaboratorId: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: collaboratorShifts.url(args, options),
    method: 'get',
})

collaboratorShifts.definition = {
    methods: ["get","head"],
    url: '/api/registros/work-shifts/collaborator/{collaboratorId}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\WorkShiftController::collaboratorShifts
* @see app/Http/Controllers/Api/WorkShiftController.php:125
* @route '/api/registros/work-shifts/collaborator/{collaboratorId}'
*/
collaboratorShifts.url = (args: { collaboratorId: string | number } | [collaboratorId: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { collaboratorId: args }
    }

    if (Array.isArray(args)) {
        args = {
            collaboratorId: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        collaboratorId: args.collaboratorId,
    }

    return collaboratorShifts.definition.url
            .replace('{collaboratorId}', parsedArgs.collaboratorId.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\WorkShiftController::collaboratorShifts
* @see app/Http/Controllers/Api/WorkShiftController.php:125
* @route '/api/registros/work-shifts/collaborator/{collaboratorId}'
*/
collaboratorShifts.get = (args: { collaboratorId: string | number } | [collaboratorId: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: collaboratorShifts.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\WorkShiftController::collaboratorShifts
* @see app/Http/Controllers/Api/WorkShiftController.php:125
* @route '/api/registros/work-shifts/collaborator/{collaboratorId}'
*/
collaboratorShifts.head = (args: { collaboratorId: string | number } | [collaboratorId: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: collaboratorShifts.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Api\WorkShiftController::collaboratorShifts
* @see app/Http/Controllers/Api/WorkShiftController.php:125
* @route '/api/registros/work-shifts/collaborator/{collaboratorId}'
*/
const collaboratorShiftsForm = (args: { collaboratorId: string | number } | [collaboratorId: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: collaboratorShifts.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\WorkShiftController::collaboratorShifts
* @see app/Http/Controllers/Api/WorkShiftController.php:125
* @route '/api/registros/work-shifts/collaborator/{collaboratorId}'
*/
collaboratorShiftsForm.get = (args: { collaboratorId: string | number } | [collaboratorId: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: collaboratorShifts.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\WorkShiftController::collaboratorShifts
* @see app/Http/Controllers/Api/WorkShiftController.php:125
* @route '/api/registros/work-shifts/collaborator/{collaboratorId}'
*/
collaboratorShiftsForm.head = (args: { collaboratorId: string | number } | [collaboratorId: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: collaboratorShifts.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

collaboratorShifts.form = collaboratorShiftsForm

/**
* @see \App\Http\Controllers\Api\WorkShiftController::store
* @see app/Http/Controllers/Api/WorkShiftController.php:28
* @route '/api/registros/work-shifts'
*/
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/api/registros/work-shifts',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\WorkShiftController::store
* @see app/Http/Controllers/Api/WorkShiftController.php:28
* @route '/api/registros/work-shifts'
*/
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\WorkShiftController::store
* @see app/Http/Controllers/Api/WorkShiftController.php:28
* @route '/api/registros/work-shifts'
*/
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Api\WorkShiftController::store
* @see app/Http/Controllers/Api/WorkShiftController.php:28
* @route '/api/registros/work-shifts'
*/
const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Api\WorkShiftController::store
* @see app/Http/Controllers/Api/WorkShiftController.php:28
* @route '/api/registros/work-shifts'
*/
storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

store.form = storeForm

/**
* @see \App\Http\Controllers\Api\WorkShiftController::update
* @see app/Http/Controllers/Api/WorkShiftController.php:64
* @route '/api/registros/work-shifts/{id}'
*/
export const update = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/api/registros/work-shifts/{id}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Api\WorkShiftController::update
* @see app/Http/Controllers/Api/WorkShiftController.php:64
* @route '/api/registros/work-shifts/{id}'
*/
update.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    if (Array.isArray(args)) {
        args = {
            id: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        id: args.id,
    }

    return update.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\WorkShiftController::update
* @see app/Http/Controllers/Api/WorkShiftController.php:64
* @route '/api/registros/work-shifts/{id}'
*/
update.put = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\Api\WorkShiftController::update
* @see app/Http/Controllers/Api/WorkShiftController.php:64
* @route '/api/registros/work-shifts/{id}'
*/
const updateForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Api\WorkShiftController::update
* @see app/Http/Controllers/Api/WorkShiftController.php:64
* @route '/api/registros/work-shifts/{id}'
*/
updateForm.put = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

update.form = updateForm

/**
* @see \App\Http\Controllers\Api\WorkShiftController::destroy
* @see app/Http/Controllers/Api/WorkShiftController.php:93
* @route '/api/registros/work-shifts/{id}'
*/
export const destroy = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/api/registros/work-shifts/{id}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Api\WorkShiftController::destroy
* @see app/Http/Controllers/Api/WorkShiftController.php:93
* @route '/api/registros/work-shifts/{id}'
*/
destroy.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    if (Array.isArray(args)) {
        args = {
            id: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        id: args.id,
    }

    return destroy.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\WorkShiftController::destroy
* @see app/Http/Controllers/Api/WorkShiftController.php:93
* @route '/api/registros/work-shifts/{id}'
*/
destroy.delete = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

/**
* @see \App\Http\Controllers\Api\WorkShiftController::destroy
* @see app/Http/Controllers/Api/WorkShiftController.php:93
* @route '/api/registros/work-shifts/{id}'
*/
const destroyForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Api\WorkShiftController::destroy
* @see app/Http/Controllers/Api/WorkShiftController.php:93
* @route '/api/registros/work-shifts/{id}'
*/
destroyForm.delete = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

destroy.form = destroyForm

/**
* @see \App\Http\Controllers\Api\WorkShiftController::monthlySchedule
* @see app/Http/Controllers/Api/WorkShiftController.php:145
* @route '/api/registros/work-shifts/monthly-schedule'
*/
export const monthlySchedule = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: monthlySchedule.url(options),
    method: 'post',
})

monthlySchedule.definition = {
    methods: ["post"],
    url: '/api/registros/work-shifts/monthly-schedule',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\WorkShiftController::monthlySchedule
* @see app/Http/Controllers/Api/WorkShiftController.php:145
* @route '/api/registros/work-shifts/monthly-schedule'
*/
monthlySchedule.url = (options?: RouteQueryOptions) => {
    return monthlySchedule.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\WorkShiftController::monthlySchedule
* @see app/Http/Controllers/Api/WorkShiftController.php:145
* @route '/api/registros/work-shifts/monthly-schedule'
*/
monthlySchedule.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: monthlySchedule.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Api\WorkShiftController::monthlySchedule
* @see app/Http/Controllers/Api/WorkShiftController.php:145
* @route '/api/registros/work-shifts/monthly-schedule'
*/
const monthlyScheduleForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: monthlySchedule.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Api\WorkShiftController::monthlySchedule
* @see app/Http/Controllers/Api/WorkShiftController.php:145
* @route '/api/registros/work-shifts/monthly-schedule'
*/
monthlyScheduleForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: monthlySchedule.url(options),
    method: 'post',
})

monthlySchedule.form = monthlyScheduleForm

const WorkShiftController = { index, show, byDate, collaboratorShifts, store, update, destroy, monthlySchedule }

export default WorkShiftController