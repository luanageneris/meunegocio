import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Api\BalanceController::history
* @see app/Http/Controllers/Api/BalanceController.php:39
* @route '/api/registros/balance'
*/
export const history = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: history.url(options),
    method: 'get',
})

history.definition = {
    methods: ["get","head"],
    url: '/api/registros/balance',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\BalanceController::history
* @see app/Http/Controllers/Api/BalanceController.php:39
* @route '/api/registros/balance'
*/
history.url = (options?: RouteQueryOptions) => {
    return history.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\BalanceController::history
* @see app/Http/Controllers/Api/BalanceController.php:39
* @route '/api/registros/balance'
*/
history.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: history.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\BalanceController::history
* @see app/Http/Controllers/Api/BalanceController.php:39
* @route '/api/registros/balance'
*/
history.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: history.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Api\BalanceController::history
* @see app/Http/Controllers/Api/BalanceController.php:39
* @route '/api/registros/balance'
*/
const historyForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: history.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\BalanceController::history
* @see app/Http/Controllers/Api/BalanceController.php:39
* @route '/api/registros/balance'
*/
historyForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: history.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\BalanceController::history
* @see app/Http/Controllers/Api/BalanceController.php:39
* @route '/api/registros/balance'
*/
historyForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: history.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

history.form = historyForm

/**
* @see \App\Http\Controllers\Api\BalanceController::store
* @see app/Http/Controllers/Api/BalanceController.php:60
* @route '/api/registros/balance'
*/
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/api/registros/balance',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\BalanceController::store
* @see app/Http/Controllers/Api/BalanceController.php:60
* @route '/api/registros/balance'
*/
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\BalanceController::store
* @see app/Http/Controllers/Api/BalanceController.php:60
* @route '/api/registros/balance'
*/
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Api\BalanceController::store
* @see app/Http/Controllers/Api/BalanceController.php:60
* @route '/api/registros/balance'
*/
const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Api\BalanceController::store
* @see app/Http/Controllers/Api/BalanceController.php:60
* @route '/api/registros/balance'
*/
storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

store.form = storeForm

/**
* @see \App\Http\Controllers\Api\BalanceController::dailyProgression
* @see app/Http/Controllers/Api/BalanceController.php:82
* @route '/api/registros/balance/daily-progression'
*/
export const dailyProgression = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: dailyProgression.url(options),
    method: 'post',
})

dailyProgression.definition = {
    methods: ["post"],
    url: '/api/registros/balance/daily-progression',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\BalanceController::dailyProgression
* @see app/Http/Controllers/Api/BalanceController.php:82
* @route '/api/registros/balance/daily-progression'
*/
dailyProgression.url = (options?: RouteQueryOptions) => {
    return dailyProgression.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\BalanceController::dailyProgression
* @see app/Http/Controllers/Api/BalanceController.php:82
* @route '/api/registros/balance/daily-progression'
*/
dailyProgression.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: dailyProgression.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Api\BalanceController::dailyProgression
* @see app/Http/Controllers/Api/BalanceController.php:82
* @route '/api/registros/balance/daily-progression'
*/
const dailyProgressionForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: dailyProgression.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Api\BalanceController::dailyProgression
* @see app/Http/Controllers/Api/BalanceController.php:82
* @route '/api/registros/balance/daily-progression'
*/
dailyProgressionForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: dailyProgression.url(options),
    method: 'post',
})

dailyProgression.form = dailyProgressionForm

/**
* @see \App\Http\Controllers\Api\BalanceController::monthlySummary
* @see app/Http/Controllers/Api/BalanceController.php:143
* @route '/api/registros/balance/monthly-summary'
*/
export const monthlySummary = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: monthlySummary.url(options),
    method: 'post',
})

monthlySummary.definition = {
    methods: ["post"],
    url: '/api/registros/balance/monthly-summary',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\BalanceController::monthlySummary
* @see app/Http/Controllers/Api/BalanceController.php:143
* @route '/api/registros/balance/monthly-summary'
*/
monthlySummary.url = (options?: RouteQueryOptions) => {
    return monthlySummary.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\BalanceController::monthlySummary
* @see app/Http/Controllers/Api/BalanceController.php:143
* @route '/api/registros/balance/monthly-summary'
*/
monthlySummary.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: monthlySummary.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Api\BalanceController::monthlySummary
* @see app/Http/Controllers/Api/BalanceController.php:143
* @route '/api/registros/balance/monthly-summary'
*/
const monthlySummaryForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: monthlySummary.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Api\BalanceController::monthlySummary
* @see app/Http/Controllers/Api/BalanceController.php:143
* @route '/api/registros/balance/monthly-summary'
*/
monthlySummaryForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: monthlySummary.url(options),
    method: 'post',
})

monthlySummary.form = monthlySummaryForm

/**
* @see \App\Http\Controllers\Api\BalanceController::yearlySummary
* @see app/Http/Controllers/Api/BalanceController.php:188
* @route '/api/registros/balance/yearly-summary'
*/
export const yearlySummary = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: yearlySummary.url(options),
    method: 'post',
})

yearlySummary.definition = {
    methods: ["post"],
    url: '/api/registros/balance/yearly-summary',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\BalanceController::yearlySummary
* @see app/Http/Controllers/Api/BalanceController.php:188
* @route '/api/registros/balance/yearly-summary'
*/
yearlySummary.url = (options?: RouteQueryOptions) => {
    return yearlySummary.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\BalanceController::yearlySummary
* @see app/Http/Controllers/Api/BalanceController.php:188
* @route '/api/registros/balance/yearly-summary'
*/
yearlySummary.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: yearlySummary.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Api\BalanceController::yearlySummary
* @see app/Http/Controllers/Api/BalanceController.php:188
* @route '/api/registros/balance/yearly-summary'
*/
const yearlySummaryForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: yearlySummary.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Api\BalanceController::yearlySummary
* @see app/Http/Controllers/Api/BalanceController.php:188
* @route '/api/registros/balance/yearly-summary'
*/
yearlySummaryForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: yearlySummary.url(options),
    method: 'post',
})

yearlySummary.form = yearlySummaryForm

const BalanceController = { history, store, dailyProgression, monthlySummary, yearlySummary }

export default BalanceController