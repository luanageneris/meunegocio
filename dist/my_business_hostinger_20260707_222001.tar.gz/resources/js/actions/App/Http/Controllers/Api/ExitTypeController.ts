import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Api\ExitTypeController::index
* @see app/Http/Controllers/Api/ExitTypeController.php:14
* @route '/api/personalizar/exit-types'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/api/personalizar/exit-types',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\ExitTypeController::index
* @see app/Http/Controllers/Api/ExitTypeController.php:14
* @route '/api/personalizar/exit-types'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\ExitTypeController::index
* @see app/Http/Controllers/Api/ExitTypeController.php:14
* @route '/api/personalizar/exit-types'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\ExitTypeController::index
* @see app/Http/Controllers/Api/ExitTypeController.php:14
* @route '/api/personalizar/exit-types'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Api\ExitTypeController::index
* @see app/Http/Controllers/Api/ExitTypeController.php:14
* @route '/api/personalizar/exit-types'
*/
const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\ExitTypeController::index
* @see app/Http/Controllers/Api/ExitTypeController.php:14
* @route '/api/personalizar/exit-types'
*/
indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\ExitTypeController::index
* @see app/Http/Controllers/Api/ExitTypeController.php:14
* @route '/api/personalizar/exit-types'
*/
indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index.form = indexForm

/**
* @see \App\Http\Controllers\Api\ExitTypeController::withTrashed
* @see app/Http/Controllers/Api/ExitTypeController.php:79
* @route '/api/personalizar/exit-types/with-trashed'
*/
export const withTrashed = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: withTrashed.url(options),
    method: 'get',
})

withTrashed.definition = {
    methods: ["get","head"],
    url: '/api/personalizar/exit-types/with-trashed',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\ExitTypeController::withTrashed
* @see app/Http/Controllers/Api/ExitTypeController.php:79
* @route '/api/personalizar/exit-types/with-trashed'
*/
withTrashed.url = (options?: RouteQueryOptions) => {
    return withTrashed.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\ExitTypeController::withTrashed
* @see app/Http/Controllers/Api/ExitTypeController.php:79
* @route '/api/personalizar/exit-types/with-trashed'
*/
withTrashed.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: withTrashed.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\ExitTypeController::withTrashed
* @see app/Http/Controllers/Api/ExitTypeController.php:79
* @route '/api/personalizar/exit-types/with-trashed'
*/
withTrashed.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: withTrashed.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Api\ExitTypeController::withTrashed
* @see app/Http/Controllers/Api/ExitTypeController.php:79
* @route '/api/personalizar/exit-types/with-trashed'
*/
const withTrashedForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: withTrashed.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\ExitTypeController::withTrashed
* @see app/Http/Controllers/Api/ExitTypeController.php:79
* @route '/api/personalizar/exit-types/with-trashed'
*/
withTrashedForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: withTrashed.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\ExitTypeController::withTrashed
* @see app/Http/Controllers/Api/ExitTypeController.php:79
* @route '/api/personalizar/exit-types/with-trashed'
*/
withTrashedForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: withTrashed.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

withTrashed.form = withTrashedForm

/**
* @see \App\Http\Controllers\Api\ExitTypeController::show
* @see app/Http/Controllers/Api/ExitTypeController.php:34
* @route '/api/personalizar/exit-types/{exitType}'
*/
export const show = (args: { exitType: number | { id: number } } | [exitType: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/api/personalizar/exit-types/{exitType}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\ExitTypeController::show
* @see app/Http/Controllers/Api/ExitTypeController.php:34
* @route '/api/personalizar/exit-types/{exitType}'
*/
show.url = (args: { exitType: number | { id: number } } | [exitType: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { exitType: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { exitType: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            exitType: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        exitType: typeof args.exitType === 'object'
        ? args.exitType.id
        : args.exitType,
    }

    return show.definition.url
            .replace('{exitType}', parsedArgs.exitType.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\ExitTypeController::show
* @see app/Http/Controllers/Api/ExitTypeController.php:34
* @route '/api/personalizar/exit-types/{exitType}'
*/
show.get = (args: { exitType: number | { id: number } } | [exitType: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\ExitTypeController::show
* @see app/Http/Controllers/Api/ExitTypeController.php:34
* @route '/api/personalizar/exit-types/{exitType}'
*/
show.head = (args: { exitType: number | { id: number } } | [exitType: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Api\ExitTypeController::show
* @see app/Http/Controllers/Api/ExitTypeController.php:34
* @route '/api/personalizar/exit-types/{exitType}'
*/
const showForm = (args: { exitType: number | { id: number } } | [exitType: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\ExitTypeController::show
* @see app/Http/Controllers/Api/ExitTypeController.php:34
* @route '/api/personalizar/exit-types/{exitType}'
*/
showForm.get = (args: { exitType: number | { id: number } } | [exitType: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\ExitTypeController::show
* @see app/Http/Controllers/Api/ExitTypeController.php:34
* @route '/api/personalizar/exit-types/{exitType}'
*/
showForm.head = (args: { exitType: number | { id: number } } | [exitType: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

show.form = showForm

/**
* @see \App\Http\Controllers\Api\ExitTypeController::restore
* @see app/Http/Controllers/Api/ExitTypeController.php:90
* @route '/api/personalizar/exit-types/{id}/restore'
*/
export const restore = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: restore.url(args, options),
    method: 'post',
})

restore.definition = {
    methods: ["post"],
    url: '/api/personalizar/exit-types/{id}/restore',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\ExitTypeController::restore
* @see app/Http/Controllers/Api/ExitTypeController.php:90
* @route '/api/personalizar/exit-types/{id}/restore'
*/
restore.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    if (Array.isArray(args)) {
        args = {
            id: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        id: args.id,
    }

    return restore.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\ExitTypeController::restore
* @see app/Http/Controllers/Api/ExitTypeController.php:90
* @route '/api/personalizar/exit-types/{id}/restore'
*/
restore.post = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: restore.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Api\ExitTypeController::restore
* @see app/Http/Controllers/Api/ExitTypeController.php:90
* @route '/api/personalizar/exit-types/{id}/restore'
*/
const restoreForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: restore.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Api\ExitTypeController::restore
* @see app/Http/Controllers/Api/ExitTypeController.php:90
* @route '/api/personalizar/exit-types/{id}/restore'
*/
restoreForm.post = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: restore.url(args, options),
    method: 'post',
})

restore.form = restoreForm

/**
* @see \App\Http\Controllers\Api\ExitTypeController::store
* @see app/Http/Controllers/Api/ExitTypeController.php:24
* @route '/api/personalizar/exit-types'
*/
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/api/personalizar/exit-types',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\ExitTypeController::store
* @see app/Http/Controllers/Api/ExitTypeController.php:24
* @route '/api/personalizar/exit-types'
*/
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\ExitTypeController::store
* @see app/Http/Controllers/Api/ExitTypeController.php:24
* @route '/api/personalizar/exit-types'
*/
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Api\ExitTypeController::store
* @see app/Http/Controllers/Api/ExitTypeController.php:24
* @route '/api/personalizar/exit-types'
*/
const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Api\ExitTypeController::store
* @see app/Http/Controllers/Api/ExitTypeController.php:24
* @route '/api/personalizar/exit-types'
*/
storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

store.form = storeForm

/**
* @see \App\Http\Controllers\Api\ExitTypeController::update
* @see app/Http/Controllers/Api/ExitTypeController.php:43
* @route '/api/personalizar/exit-types/{exitType}'
*/
export const update = (args: { exitType: number | { id: number } } | [exitType: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/api/personalizar/exit-types/{exitType}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Api\ExitTypeController::update
* @see app/Http/Controllers/Api/ExitTypeController.php:43
* @route '/api/personalizar/exit-types/{exitType}'
*/
update.url = (args: { exitType: number | { id: number } } | [exitType: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { exitType: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { exitType: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            exitType: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        exitType: typeof args.exitType === 'object'
        ? args.exitType.id
        : args.exitType,
    }

    return update.definition.url
            .replace('{exitType}', parsedArgs.exitType.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\ExitTypeController::update
* @see app/Http/Controllers/Api/ExitTypeController.php:43
* @route '/api/personalizar/exit-types/{exitType}'
*/
update.put = (args: { exitType: number | { id: number } } | [exitType: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\Api\ExitTypeController::update
* @see app/Http/Controllers/Api/ExitTypeController.php:43
* @route '/api/personalizar/exit-types/{exitType}'
*/
const updateForm = (args: { exitType: number | { id: number } } | [exitType: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Api\ExitTypeController::update
* @see app/Http/Controllers/Api/ExitTypeController.php:43
* @route '/api/personalizar/exit-types/{exitType}'
*/
updateForm.put = (args: { exitType: number | { id: number } } | [exitType: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

update.form = updateForm

/**
* @see \App\Http\Controllers\Api\ExitTypeController::destroy
* @see app/Http/Controllers/Api/ExitTypeController.php:58
* @route '/api/personalizar/exit-types/{exitType}'
*/
export const destroy = (args: { exitType: number | { id: number } } | [exitType: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/api/personalizar/exit-types/{exitType}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Api\ExitTypeController::destroy
* @see app/Http/Controllers/Api/ExitTypeController.php:58
* @route '/api/personalizar/exit-types/{exitType}'
*/
destroy.url = (args: { exitType: number | { id: number } } | [exitType: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { exitType: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { exitType: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            exitType: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        exitType: typeof args.exitType === 'object'
        ? args.exitType.id
        : args.exitType,
    }

    return destroy.definition.url
            .replace('{exitType}', parsedArgs.exitType.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\ExitTypeController::destroy
* @see app/Http/Controllers/Api/ExitTypeController.php:58
* @route '/api/personalizar/exit-types/{exitType}'
*/
destroy.delete = (args: { exitType: number | { id: number } } | [exitType: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

/**
* @see \App\Http\Controllers\Api\ExitTypeController::destroy
* @see app/Http/Controllers/Api/ExitTypeController.php:58
* @route '/api/personalizar/exit-types/{exitType}'
*/
const destroyForm = (args: { exitType: number | { id: number } } | [exitType: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Api\ExitTypeController::destroy
* @see app/Http/Controllers/Api/ExitTypeController.php:58
* @route '/api/personalizar/exit-types/{exitType}'
*/
destroyForm.delete = (args: { exitType: number | { id: number } } | [exitType: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

destroy.form = destroyForm

const ExitTypeController = { index, withTrashed, show, restore, store, update, destroy }

export default ExitTypeController