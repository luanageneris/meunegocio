import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Api\AuthController::loginGoogle
* @see app/Http/Controllers/Api/AuthController.php:87
* @route '/api/auth/google'
*/
export const loginGoogle = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: loginGoogle.url(options),
    method: 'post',
})

loginGoogle.definition = {
    methods: ["post"],
    url: '/api/auth/google',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\AuthController::loginGoogle
* @see app/Http/Controllers/Api/AuthController.php:87
* @route '/api/auth/google'
*/
loginGoogle.url = (options?: RouteQueryOptions) => {
    return loginGoogle.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\AuthController::loginGoogle
* @see app/Http/Controllers/Api/AuthController.php:87
* @route '/api/auth/google'
*/
loginGoogle.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: loginGoogle.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Api\AuthController::loginGoogle
* @see app/Http/Controllers/Api/AuthController.php:87
* @route '/api/auth/google'
*/
const loginGoogleForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: loginGoogle.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Api\AuthController::loginGoogle
* @see app/Http/Controllers/Api/AuthController.php:87
* @route '/api/auth/google'
*/
loginGoogleForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: loginGoogle.url(options),
    method: 'post',
})

loginGoogle.form = loginGoogleForm

/**
* @see \App\Http\Controllers\Api\AuthController::pendingRegistration
* @see app/Http/Controllers/Api/AuthController.php:145
* @route '/api/auth/pending-registration'
*/
export const pendingRegistration = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: pendingRegistration.url(options),
    method: 'get',
})

pendingRegistration.definition = {
    methods: ["get","head"],
    url: '/api/auth/pending-registration',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\AuthController::pendingRegistration
* @see app/Http/Controllers/Api/AuthController.php:145
* @route '/api/auth/pending-registration'
*/
pendingRegistration.url = (options?: RouteQueryOptions) => {
    return pendingRegistration.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\AuthController::pendingRegistration
* @see app/Http/Controllers/Api/AuthController.php:145
* @route '/api/auth/pending-registration'
*/
pendingRegistration.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: pendingRegistration.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\AuthController::pendingRegistration
* @see app/Http/Controllers/Api/AuthController.php:145
* @route '/api/auth/pending-registration'
*/
pendingRegistration.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: pendingRegistration.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Api\AuthController::pendingRegistration
* @see app/Http/Controllers/Api/AuthController.php:145
* @route '/api/auth/pending-registration'
*/
const pendingRegistrationForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: pendingRegistration.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\AuthController::pendingRegistration
* @see app/Http/Controllers/Api/AuthController.php:145
* @route '/api/auth/pending-registration'
*/
pendingRegistrationForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: pendingRegistration.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\AuthController::pendingRegistration
* @see app/Http/Controllers/Api/AuthController.php:145
* @route '/api/auth/pending-registration'
*/
pendingRegistrationForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: pendingRegistration.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

pendingRegistration.form = pendingRegistrationForm

/**
* @see \App\Http\Controllers\Api\AuthController::registerGoogle
* @see app/Http/Controllers/Api/AuthController.php:166
* @route '/api/auth/register'
*/
export const registerGoogle = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: registerGoogle.url(options),
    method: 'post',
})

registerGoogle.definition = {
    methods: ["post"],
    url: '/api/auth/register',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\AuthController::registerGoogle
* @see app/Http/Controllers/Api/AuthController.php:166
* @route '/api/auth/register'
*/
registerGoogle.url = (options?: RouteQueryOptions) => {
    return registerGoogle.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\AuthController::registerGoogle
* @see app/Http/Controllers/Api/AuthController.php:166
* @route '/api/auth/register'
*/
registerGoogle.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: registerGoogle.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Api\AuthController::registerGoogle
* @see app/Http/Controllers/Api/AuthController.php:166
* @route '/api/auth/register'
*/
const registerGoogleForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: registerGoogle.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Api\AuthController::registerGoogle
* @see app/Http/Controllers/Api/AuthController.php:166
* @route '/api/auth/register'
*/
registerGoogleForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: registerGoogle.url(options),
    method: 'post',
})

registerGoogle.form = registerGoogleForm

/**
* @see \App\Http\Controllers\Api\AuthController::logout
* @see app/Http/Controllers/Api/AuthController.php:323
* @route '/api/auth/logout'
*/
export const logout = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: logout.url(options),
    method: 'post',
})

logout.definition = {
    methods: ["post"],
    url: '/api/auth/logout',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\AuthController::logout
* @see app/Http/Controllers/Api/AuthController.php:323
* @route '/api/auth/logout'
*/
logout.url = (options?: RouteQueryOptions) => {
    return logout.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\AuthController::logout
* @see app/Http/Controllers/Api/AuthController.php:323
* @route '/api/auth/logout'
*/
logout.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: logout.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Api\AuthController::logout
* @see app/Http/Controllers/Api/AuthController.php:323
* @route '/api/auth/logout'
*/
const logoutForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: logout.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Api\AuthController::logout
* @see app/Http/Controllers/Api/AuthController.php:323
* @route '/api/auth/logout'
*/
logoutForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: logout.url(options),
    method: 'post',
})

logout.form = logoutForm

/**
* @see \App\Http\Controllers\Api\AuthController::user
* @see app/Http/Controllers/Api/AuthController.php:313
* @route '/api/auth/user'
*/
export const user = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: user.url(options),
    method: 'get',
})

user.definition = {
    methods: ["get","head"],
    url: '/api/auth/user',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\AuthController::user
* @see app/Http/Controllers/Api/AuthController.php:313
* @route '/api/auth/user'
*/
user.url = (options?: RouteQueryOptions) => {
    return user.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\AuthController::user
* @see app/Http/Controllers/Api/AuthController.php:313
* @route '/api/auth/user'
*/
user.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: user.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\AuthController::user
* @see app/Http/Controllers/Api/AuthController.php:313
* @route '/api/auth/user'
*/
user.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: user.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Api\AuthController::user
* @see app/Http/Controllers/Api/AuthController.php:313
* @route '/api/auth/user'
*/
const userForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: user.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\AuthController::user
* @see app/Http/Controllers/Api/AuthController.php:313
* @route '/api/auth/user'
*/
userForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: user.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\AuthController::user
* @see app/Http/Controllers/Api/AuthController.php:313
* @route '/api/auth/user'
*/
userForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: user.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

user.form = userForm

/**
* @see \App\Http\Controllers\Api\AuthController::impersonate
* @see app/Http/Controllers/Api/AuthController.php:342
* @route '/api/auth/impersonate/{user}'
*/
export const impersonate = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: impersonate.url(args, options),
    method: 'post',
})

impersonate.definition = {
    methods: ["post"],
    url: '/api/auth/impersonate/{user}',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\AuthController::impersonate
* @see app/Http/Controllers/Api/AuthController.php:342
* @route '/api/auth/impersonate/{user}'
*/
impersonate.url = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { user: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { user: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            user: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        user: typeof args.user === 'object'
        ? args.user.id
        : args.user,
    }

    return impersonate.definition.url
            .replace('{user}', parsedArgs.user.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\AuthController::impersonate
* @see app/Http/Controllers/Api/AuthController.php:342
* @route '/api/auth/impersonate/{user}'
*/
impersonate.post = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: impersonate.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Api\AuthController::impersonate
* @see app/Http/Controllers/Api/AuthController.php:342
* @route '/api/auth/impersonate/{user}'
*/
const impersonateForm = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: impersonate.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Api\AuthController::impersonate
* @see app/Http/Controllers/Api/AuthController.php:342
* @route '/api/auth/impersonate/{user}'
*/
impersonateForm.post = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: impersonate.url(args, options),
    method: 'post',
})

impersonate.form = impersonateForm

/**
* @see \App\Http\Controllers\Api\AuthController::redirectToGoogle
* @see app/Http/Controllers/Api/AuthController.php:29
* @route '/auth/google'
*/
export const redirectToGoogle = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: redirectToGoogle.url(options),
    method: 'get',
})

redirectToGoogle.definition = {
    methods: ["get","head"],
    url: '/auth/google',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\AuthController::redirectToGoogle
* @see app/Http/Controllers/Api/AuthController.php:29
* @route '/auth/google'
*/
redirectToGoogle.url = (options?: RouteQueryOptions) => {
    return redirectToGoogle.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\AuthController::redirectToGoogle
* @see app/Http/Controllers/Api/AuthController.php:29
* @route '/auth/google'
*/
redirectToGoogle.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: redirectToGoogle.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\AuthController::redirectToGoogle
* @see app/Http/Controllers/Api/AuthController.php:29
* @route '/auth/google'
*/
redirectToGoogle.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: redirectToGoogle.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Api\AuthController::redirectToGoogle
* @see app/Http/Controllers/Api/AuthController.php:29
* @route '/auth/google'
*/
const redirectToGoogleForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: redirectToGoogle.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\AuthController::redirectToGoogle
* @see app/Http/Controllers/Api/AuthController.php:29
* @route '/auth/google'
*/
redirectToGoogleForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: redirectToGoogle.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\AuthController::redirectToGoogle
* @see app/Http/Controllers/Api/AuthController.php:29
* @route '/auth/google'
*/
redirectToGoogleForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: redirectToGoogle.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

redirectToGoogle.form = redirectToGoogleForm

/**
* @see \App\Http\Controllers\Api\AuthController::handleGoogleCallback
* @see app/Http/Controllers/Api/AuthController.php:40
* @route '/auth/google/callback'
*/
export const handleGoogleCallback = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: handleGoogleCallback.url(options),
    method: 'get',
})

handleGoogleCallback.definition = {
    methods: ["get","head"],
    url: '/auth/google/callback',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\AuthController::handleGoogleCallback
* @see app/Http/Controllers/Api/AuthController.php:40
* @route '/auth/google/callback'
*/
handleGoogleCallback.url = (options?: RouteQueryOptions) => {
    return handleGoogleCallback.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\AuthController::handleGoogleCallback
* @see app/Http/Controllers/Api/AuthController.php:40
* @route '/auth/google/callback'
*/
handleGoogleCallback.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: handleGoogleCallback.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\AuthController::handleGoogleCallback
* @see app/Http/Controllers/Api/AuthController.php:40
* @route '/auth/google/callback'
*/
handleGoogleCallback.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: handleGoogleCallback.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Api\AuthController::handleGoogleCallback
* @see app/Http/Controllers/Api/AuthController.php:40
* @route '/auth/google/callback'
*/
const handleGoogleCallbackForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: handleGoogleCallback.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\AuthController::handleGoogleCallback
* @see app/Http/Controllers/Api/AuthController.php:40
* @route '/auth/google/callback'
*/
handleGoogleCallbackForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: handleGoogleCallback.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\AuthController::handleGoogleCallback
* @see app/Http/Controllers/Api/AuthController.php:40
* @route '/auth/google/callback'
*/
handleGoogleCallbackForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: handleGoogleCallback.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

handleGoogleCallback.form = handleGoogleCallbackForm

const AuthController = { loginGoogle, pendingRegistration, registerGoogle, logout, user, impersonate, redirectToGoogle, handleGoogleCallback }

export default AuthController