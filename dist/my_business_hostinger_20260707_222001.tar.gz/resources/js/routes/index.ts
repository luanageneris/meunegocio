import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../wayfinder'
/**
* @see routes/web.php:15
* @route '/login'
*/
export const login = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: login.url(options),
    method: 'get',
})

login.definition = {
    methods: ["get","head"],
    url: '/login',
} satisfies RouteDefinition<["get","head"]>

/**
* @see routes/web.php:15
* @route '/login'
*/
login.url = (options?: RouteQueryOptions) => {
    return login.definition.url + queryParams(options)
}

/**
* @see routes/web.php:15
* @route '/login'
*/
login.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: login.url(options),
    method: 'get',
})

/**
* @see routes/web.php:15
* @route '/login'
*/
login.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: login.url(options),
    method: 'head',
})

/**
* @see routes/web.php:15
* @route '/login'
*/
const loginForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: login.url(options),
    method: 'get',
})

/**
* @see routes/web.php:15
* @route '/login'
*/
loginForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: login.url(options),
    method: 'get',
})

/**
* @see routes/web.php:15
* @route '/login'
*/
loginForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: login.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

login.form = loginForm

/**
* @see \Laravel\Fortify\Http\Controllers\AuthenticatedSessionController::logout
* @see vendor/laravel/fortify/src/Http/Controllers/AuthenticatedSessionController.php:100
* @route '/logout'
*/
export const logout = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: logout.url(options),
    method: 'post',
})

logout.definition = {
    methods: ["post"],
    url: '/logout',
} satisfies RouteDefinition<["post"]>

/**
* @see \Laravel\Fortify\Http\Controllers\AuthenticatedSessionController::logout
* @see vendor/laravel/fortify/src/Http/Controllers/AuthenticatedSessionController.php:100
* @route '/logout'
*/
logout.url = (options?: RouteQueryOptions) => {
    return logout.definition.url + queryParams(options)
}

/**
* @see \Laravel\Fortify\Http\Controllers\AuthenticatedSessionController::logout
* @see vendor/laravel/fortify/src/Http/Controllers/AuthenticatedSessionController.php:100
* @route '/logout'
*/
logout.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: logout.url(options),
    method: 'post',
})

/**
* @see \Laravel\Fortify\Http\Controllers\AuthenticatedSessionController::logout
* @see vendor/laravel/fortify/src/Http/Controllers/AuthenticatedSessionController.php:100
* @route '/logout'
*/
const logoutForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: logout.url(options),
    method: 'post',
})

/**
* @see \Laravel\Fortify\Http\Controllers\AuthenticatedSessionController::logout
* @see vendor/laravel/fortify/src/Http/Controllers/AuthenticatedSessionController.php:100
* @route '/logout'
*/
logoutForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: logout.url(options),
    method: 'post',
})

logout.form = logoutForm

/**
* @see \Laravel\Fortify\Http\Controllers\RegisteredUserController::register
* @see vendor/laravel/fortify/src/Http/Controllers/RegisteredUserController.php:41
* @route '/register'
*/
export const register = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: register.url(options),
    method: 'get',
})

register.definition = {
    methods: ["get","head"],
    url: '/register',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \Laravel\Fortify\Http\Controllers\RegisteredUserController::register
* @see vendor/laravel/fortify/src/Http/Controllers/RegisteredUserController.php:41
* @route '/register'
*/
register.url = (options?: RouteQueryOptions) => {
    return register.definition.url + queryParams(options)
}

/**
* @see \Laravel\Fortify\Http\Controllers\RegisteredUserController::register
* @see vendor/laravel/fortify/src/Http/Controllers/RegisteredUserController.php:41
* @route '/register'
*/
register.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: register.url(options),
    method: 'get',
})

/**
* @see \Laravel\Fortify\Http\Controllers\RegisteredUserController::register
* @see vendor/laravel/fortify/src/Http/Controllers/RegisteredUserController.php:41
* @route '/register'
*/
register.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: register.url(options),
    method: 'head',
})

/**
* @see \Laravel\Fortify\Http\Controllers\RegisteredUserController::register
* @see vendor/laravel/fortify/src/Http/Controllers/RegisteredUserController.php:41
* @route '/register'
*/
const registerForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: register.url(options),
    method: 'get',
})

/**
* @see \Laravel\Fortify\Http\Controllers\RegisteredUserController::register
* @see vendor/laravel/fortify/src/Http/Controllers/RegisteredUserController.php:41
* @route '/register'
*/
registerForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: register.url(options),
    method: 'get',
})

/**
* @see \Laravel\Fortify\Http\Controllers\RegisteredUserController::register
* @see vendor/laravel/fortify/src/Http/Controllers/RegisteredUserController.php:41
* @route '/register'
*/
registerForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: register.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

register.form = registerForm

/**
* @see routes/web.php:9
* @route '/'
*/
export const home = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: home.url(options),
    method: 'get',
})

home.definition = {
    methods: ["get","head"],
    url: '/',
} satisfies RouteDefinition<["get","head"]>

/**
* @see routes/web.php:9
* @route '/'
*/
home.url = (options?: RouteQueryOptions) => {
    return home.definition.url + queryParams(options)
}

/**
* @see routes/web.php:9
* @route '/'
*/
home.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: home.url(options),
    method: 'get',
})

/**
* @see routes/web.php:9
* @route '/'
*/
home.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: home.url(options),
    method: 'head',
})

/**
* @see routes/web.php:9
* @route '/'
*/
const homeForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: home.url(options),
    method: 'get',
})

/**
* @see routes/web.php:9
* @route '/'
*/
homeForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: home.url(options),
    method: 'get',
})

/**
* @see routes/web.php:9
* @route '/'
*/
homeForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: home.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

home.form = homeForm

/**
* @see \Illuminate\Routing\RedirectController::__invoke
* @see vendor/laravel/framework/src/Illuminate/Routing/RedirectController.php:19
* @route '/painel'
*/
export const painel = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: painel.url(options),
    method: 'get',
})

painel.definition = {
    methods: ["get","head","post","put","patch","delete","options"],
    url: '/painel',
} satisfies RouteDefinition<["get","head","post","put","patch","delete","options"]>

/**
* @see \Illuminate\Routing\RedirectController::__invoke
* @see vendor/laravel/framework/src/Illuminate/Routing/RedirectController.php:19
* @route '/painel'
*/
painel.url = (options?: RouteQueryOptions) => {
    return painel.definition.url + queryParams(options)
}

/**
* @see \Illuminate\Routing\RedirectController::__invoke
* @see vendor/laravel/framework/src/Illuminate/Routing/RedirectController.php:19
* @route '/painel'
*/
painel.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: painel.url(options),
    method: 'get',
})

/**
* @see \Illuminate\Routing\RedirectController::__invoke
* @see vendor/laravel/framework/src/Illuminate/Routing/RedirectController.php:19
* @route '/painel'
*/
painel.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: painel.url(options),
    method: 'head',
})

/**
* @see \Illuminate\Routing\RedirectController::__invoke
* @see vendor/laravel/framework/src/Illuminate/Routing/RedirectController.php:19
* @route '/painel'
*/
painel.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: painel.url(options),
    method: 'post',
})

/**
* @see \Illuminate\Routing\RedirectController::__invoke
* @see vendor/laravel/framework/src/Illuminate/Routing/RedirectController.php:19
* @route '/painel'
*/
painel.put = (options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: painel.url(options),
    method: 'put',
})

/**
* @see \Illuminate\Routing\RedirectController::__invoke
* @see vendor/laravel/framework/src/Illuminate/Routing/RedirectController.php:19
* @route '/painel'
*/
painel.patch = (options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: painel.url(options),
    method: 'patch',
})

/**
* @see \Illuminate\Routing\RedirectController::__invoke
* @see vendor/laravel/framework/src/Illuminate/Routing/RedirectController.php:19
* @route '/painel'
*/
painel.delete = (options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: painel.url(options),
    method: 'delete',
})

/**
* @see \Illuminate\Routing\RedirectController::__invoke
* @see vendor/laravel/framework/src/Illuminate/Routing/RedirectController.php:19
* @route '/painel'
*/
painel.options = (options?: RouteQueryOptions): RouteDefinition<'options'> => ({
    url: painel.url(options),
    method: 'options',
})

/**
* @see \Illuminate\Routing\RedirectController::__invoke
* @see vendor/laravel/framework/src/Illuminate/Routing/RedirectController.php:19
* @route '/painel'
*/
const painelForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: painel.url(options),
    method: 'get',
})

/**
* @see \Illuminate\Routing\RedirectController::__invoke
* @see vendor/laravel/framework/src/Illuminate/Routing/RedirectController.php:19
* @route '/painel'
*/
painelForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: painel.url(options),
    method: 'get',
})

/**
* @see \Illuminate\Routing\RedirectController::__invoke
* @see vendor/laravel/framework/src/Illuminate/Routing/RedirectController.php:19
* @route '/painel'
*/
painelForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: painel.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

/**
* @see \Illuminate\Routing\RedirectController::__invoke
* @see vendor/laravel/framework/src/Illuminate/Routing/RedirectController.php:19
* @route '/painel'
*/
painelForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: painel.url(options),
    method: 'post',
})

/**
* @see \Illuminate\Routing\RedirectController::__invoke
* @see vendor/laravel/framework/src/Illuminate/Routing/RedirectController.php:19
* @route '/painel'
*/
painelForm.put = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: painel.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \Illuminate\Routing\RedirectController::__invoke
* @see vendor/laravel/framework/src/Illuminate/Routing/RedirectController.php:19
* @route '/painel'
*/
painelForm.patch = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: painel.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PATCH',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \Illuminate\Routing\RedirectController::__invoke
* @see vendor/laravel/framework/src/Illuminate/Routing/RedirectController.php:19
* @route '/painel'
*/
painelForm.delete = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: painel.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \Illuminate\Routing\RedirectController::__invoke
* @see vendor/laravel/framework/src/Illuminate/Routing/RedirectController.php:19
* @route '/painel'
*/
painelForm.options = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: painel.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'OPTIONS',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

painel.form = painelForm

/**
* @see routes/web.php:45
* @route '/registros'
*/
export const registros = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: registros.url(options),
    method: 'get',
})

registros.definition = {
    methods: ["get","head"],
    url: '/registros',
} satisfies RouteDefinition<["get","head"]>

/**
* @see routes/web.php:45
* @route '/registros'
*/
registros.url = (options?: RouteQueryOptions) => {
    return registros.definition.url + queryParams(options)
}

/**
* @see routes/web.php:45
* @route '/registros'
*/
registros.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: registros.url(options),
    method: 'get',
})

/**
* @see routes/web.php:45
* @route '/registros'
*/
registros.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: registros.url(options),
    method: 'head',
})

/**
* @see routes/web.php:45
* @route '/registros'
*/
const registrosForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: registros.url(options),
    method: 'get',
})

/**
* @see routes/web.php:45
* @route '/registros'
*/
registrosForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: registros.url(options),
    method: 'get',
})

/**
* @see routes/web.php:45
* @route '/registros'
*/
registrosForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: registros.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

registros.form = registrosForm

/**
* @see routes/web.php:50
* @route '/personalizar'
*/
export const personalizar = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: personalizar.url(options),
    method: 'get',
})

personalizar.definition = {
    methods: ["get","head"],
    url: '/personalizar',
} satisfies RouteDefinition<["get","head"]>

/**
* @see routes/web.php:50
* @route '/personalizar'
*/
personalizar.url = (options?: RouteQueryOptions) => {
    return personalizar.definition.url + queryParams(options)
}

/**
* @see routes/web.php:50
* @route '/personalizar'
*/
personalizar.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: personalizar.url(options),
    method: 'get',
})

/**
* @see routes/web.php:50
* @route '/personalizar'
*/
personalizar.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: personalizar.url(options),
    method: 'head',
})

/**
* @see routes/web.php:50
* @route '/personalizar'
*/
const personalizarForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: personalizar.url(options),
    method: 'get',
})

/**
* @see routes/web.php:50
* @route '/personalizar'
*/
personalizarForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: personalizar.url(options),
    method: 'get',
})

/**
* @see routes/web.php:50
* @route '/personalizar'
*/
personalizarForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: personalizar.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

personalizar.form = personalizarForm

/**
* @see routes/web.php:55
* @route '/minha-conta'
*/
export const minhaConta = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: minhaConta.url(options),
    method: 'get',
})

minhaConta.definition = {
    methods: ["get","head"],
    url: '/minha-conta',
} satisfies RouteDefinition<["get","head"]>

/**
* @see routes/web.php:55
* @route '/minha-conta'
*/
minhaConta.url = (options?: RouteQueryOptions) => {
    return minhaConta.definition.url + queryParams(options)
}

/**
* @see routes/web.php:55
* @route '/minha-conta'
*/
minhaConta.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: minhaConta.url(options),
    method: 'get',
})

/**
* @see routes/web.php:55
* @route '/minha-conta'
*/
minhaConta.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: minhaConta.url(options),
    method: 'head',
})

/**
* @see routes/web.php:55
* @route '/minha-conta'
*/
const minhaContaForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: minhaConta.url(options),
    method: 'get',
})

/**
* @see routes/web.php:55
* @route '/minha-conta'
*/
minhaContaForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: minhaConta.url(options),
    method: 'get',
})

/**
* @see routes/web.php:55
* @route '/minha-conta'
*/
minhaContaForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: minhaConta.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

minhaConta.form = minhaContaForm

/**
* @see routes/web.php:60
* @route '/colaboradores'
*/
export const colaboradores = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: colaboradores.url(options),
    method: 'get',
})

colaboradores.definition = {
    methods: ["get","head"],
    url: '/colaboradores',
} satisfies RouteDefinition<["get","head"]>

/**
* @see routes/web.php:60
* @route '/colaboradores'
*/
colaboradores.url = (options?: RouteQueryOptions) => {
    return colaboradores.definition.url + queryParams(options)
}

/**
* @see routes/web.php:60
* @route '/colaboradores'
*/
colaboradores.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: colaboradores.url(options),
    method: 'get',
})

/**
* @see routes/web.php:60
* @route '/colaboradores'
*/
colaboradores.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: colaboradores.url(options),
    method: 'head',
})

/**
* @see routes/web.php:60
* @route '/colaboradores'
*/
const colaboradoresForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: colaboradores.url(options),
    method: 'get',
})

/**
* @see routes/web.php:60
* @route '/colaboradores'
*/
colaboradoresForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: colaboradores.url(options),
    method: 'get',
})

/**
* @see routes/web.php:60
* @route '/colaboradores'
*/
colaboradoresForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: colaboradores.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

colaboradores.form = colaboradoresForm

/**
* @see routes/web.php:65
* @route '/historico'
*/
export const historico = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: historico.url(options),
    method: 'get',
})

historico.definition = {
    methods: ["get","head"],
    url: '/historico',
} satisfies RouteDefinition<["get","head"]>

/**
* @see routes/web.php:65
* @route '/historico'
*/
historico.url = (options?: RouteQueryOptions) => {
    return historico.definition.url + queryParams(options)
}

/**
* @see routes/web.php:65
* @route '/historico'
*/
historico.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: historico.url(options),
    method: 'get',
})

/**
* @see routes/web.php:65
* @route '/historico'
*/
historico.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: historico.url(options),
    method: 'head',
})

/**
* @see routes/web.php:65
* @route '/historico'
*/
const historicoForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: historico.url(options),
    method: 'get',
})

/**
* @see routes/web.php:65
* @route '/historico'
*/
historicoForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: historico.url(options),
    method: 'get',
})

/**
* @see routes/web.php:65
* @route '/historico'
*/
historicoForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: historico.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

historico.form = historicoForm

/**
* @see routes/web.php:70
* @route '/suporte'
*/
export const suporte = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: suporte.url(options),
    method: 'get',
})

suporte.definition = {
    methods: ["get","head"],
    url: '/suporte',
} satisfies RouteDefinition<["get","head"]>

/**
* @see routes/web.php:70
* @route '/suporte'
*/
suporte.url = (options?: RouteQueryOptions) => {
    return suporte.definition.url + queryParams(options)
}

/**
* @see routes/web.php:70
* @route '/suporte'
*/
suporte.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: suporte.url(options),
    method: 'get',
})

/**
* @see routes/web.php:70
* @route '/suporte'
*/
suporte.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: suporte.url(options),
    method: 'head',
})

/**
* @see routes/web.php:70
* @route '/suporte'
*/
const suporteForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: suporte.url(options),
    method: 'get',
})

/**
* @see routes/web.php:70
* @route '/suporte'
*/
suporteForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: suporte.url(options),
    method: 'get',
})

/**
* @see routes/web.php:70
* @route '/suporte'
*/
suporteForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: suporte.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

suporte.form = suporteForm

/**
* @see routes/web.php:76
* @route '/politica-de-privacidade'
*/
export const politicaPrivacidade = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: politicaPrivacidade.url(options),
    method: 'get',
})

politicaPrivacidade.definition = {
    methods: ["get","head"],
    url: '/politica-de-privacidade',
} satisfies RouteDefinition<["get","head"]>

/**
* @see routes/web.php:76
* @route '/politica-de-privacidade'
*/
politicaPrivacidade.url = (options?: RouteQueryOptions) => {
    return politicaPrivacidade.definition.url + queryParams(options)
}

/**
* @see routes/web.php:76
* @route '/politica-de-privacidade'
*/
politicaPrivacidade.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: politicaPrivacidade.url(options),
    method: 'get',
})

/**
* @see routes/web.php:76
* @route '/politica-de-privacidade'
*/
politicaPrivacidade.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: politicaPrivacidade.url(options),
    method: 'head',
})

/**
* @see routes/web.php:76
* @route '/politica-de-privacidade'
*/
const politicaPrivacidadeForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: politicaPrivacidade.url(options),
    method: 'get',
})

/**
* @see routes/web.php:76
* @route '/politica-de-privacidade'
*/
politicaPrivacidadeForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: politicaPrivacidade.url(options),
    method: 'get',
})

/**
* @see routes/web.php:76
* @route '/politica-de-privacidade'
*/
politicaPrivacidadeForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: politicaPrivacidade.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

politicaPrivacidade.form = politicaPrivacidadeForm

/**
* @see routes/web.php:80
* @route '/dashboard'
*/
export const dashboard = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: dashboard.url(options),
    method: 'get',
})

dashboard.definition = {
    methods: ["get","head"],
    url: '/dashboard',
} satisfies RouteDefinition<["get","head"]>

/**
* @see routes/web.php:80
* @route '/dashboard'
*/
dashboard.url = (options?: RouteQueryOptions) => {
    return dashboard.definition.url + queryParams(options)
}

/**
* @see routes/web.php:80
* @route '/dashboard'
*/
dashboard.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: dashboard.url(options),
    method: 'get',
})

/**
* @see routes/web.php:80
* @route '/dashboard'
*/
dashboard.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: dashboard.url(options),
    method: 'head',
})

/**
* @see routes/web.php:80
* @route '/dashboard'
*/
const dashboardForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: dashboard.url(options),
    method: 'get',
})

/**
* @see routes/web.php:80
* @route '/dashboard'
*/
dashboardForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: dashboard.url(options),
    method: 'get',
})

/**
* @see routes/web.php:80
* @route '/dashboard'
*/
dashboardForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: dashboard.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

dashboard.form = dashboardForm
