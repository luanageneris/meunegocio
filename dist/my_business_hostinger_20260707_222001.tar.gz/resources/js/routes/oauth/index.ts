import callback from './callback'

const oauth = {
    callback: Object.assign(callback, callback),
}

export default oauth