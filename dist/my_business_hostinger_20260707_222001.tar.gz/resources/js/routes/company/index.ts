import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../wayfinder'
/**
* @see \App\Http\Controllers\Api\CompanyController::show
* @see app/Http/Controllers/Api/CompanyController.php:18
* @route '/api/company'
*/
export const show = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/api/company',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\CompanyController::show
* @see app/Http/Controllers/Api/CompanyController.php:18
* @route '/api/company'
*/
show.url = (options?: RouteQueryOptions) => {
    return show.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\CompanyController::show
* @see app/Http/Controllers/Api/CompanyController.php:18
* @route '/api/company'
*/
show.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\CompanyController::show
* @see app/Http/Controllers/Api/CompanyController.php:18
* @route '/api/company'
*/
show.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Api\CompanyController::show
* @see app/Http/Controllers/Api/CompanyController.php:18
* @route '/api/company'
*/
const showForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\CompanyController::show
* @see app/Http/Controllers/Api/CompanyController.php:18
* @route '/api/company'
*/
showForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\CompanyController::show
* @see app/Http/Controllers/Api/CompanyController.php:18
* @route '/api/company'
*/
showForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

show.form = showForm

/**
* @see \App\Http\Controllers\Api\CompanyController::needsSetup
* @see app/Http/Controllers/Api/CompanyController.php:62
* @route '/api/company/needs-setup'
*/
export const needsSetup = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: needsSetup.url(options),
    method: 'get',
})

needsSetup.definition = {
    methods: ["get","head"],
    url: '/api/company/needs-setup',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\CompanyController::needsSetup
* @see app/Http/Controllers/Api/CompanyController.php:62
* @route '/api/company/needs-setup'
*/
needsSetup.url = (options?: RouteQueryOptions) => {
    return needsSetup.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\CompanyController::needsSetup
* @see app/Http/Controllers/Api/CompanyController.php:62
* @route '/api/company/needs-setup'
*/
needsSetup.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: needsSetup.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\CompanyController::needsSetup
* @see app/Http/Controllers/Api/CompanyController.php:62
* @route '/api/company/needs-setup'
*/
needsSetup.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: needsSetup.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Api\CompanyController::needsSetup
* @see app/Http/Controllers/Api/CompanyController.php:62
* @route '/api/company/needs-setup'
*/
const needsSetupForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: needsSetup.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\CompanyController::needsSetup
* @see app/Http/Controllers/Api/CompanyController.php:62
* @route '/api/company/needs-setup'
*/
needsSetupForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: needsSetup.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\CompanyController::needsSetup
* @see app/Http/Controllers/Api/CompanyController.php:62
* @route '/api/company/needs-setup'
*/
needsSetupForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: needsSetup.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

needsSetup.form = needsSetupForm

/**
* @see \App\Http\Controllers\Api\CompanyController::update
* @see app/Http/Controllers/Api/CompanyController.php:36
* @route '/api/company'
*/
export const update = (options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/api/company',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Api\CompanyController::update
* @see app/Http/Controllers/Api/CompanyController.php:36
* @route '/api/company'
*/
update.url = (options?: RouteQueryOptions) => {
    return update.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\CompanyController::update
* @see app/Http/Controllers/Api/CompanyController.php:36
* @route '/api/company'
*/
update.put = (options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\Api\CompanyController::update
* @see app/Http/Controllers/Api/CompanyController.php:36
* @route '/api/company'
*/
const updateForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Api\CompanyController::update
* @see app/Http/Controllers/Api/CompanyController.php:36
* @route '/api/company'
*/
updateForm.put = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

update.form = updateForm

/**
* @see \App\Http\Controllers\Api\CompanyController::destroy
* @see app/Http/Controllers/Api/CompanyController.php:86
* @route '/api/company'
*/
export const destroy = (options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/api/company',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Api\CompanyController::destroy
* @see app/Http/Controllers/Api/CompanyController.php:86
* @route '/api/company'
*/
destroy.url = (options?: RouteQueryOptions) => {
    return destroy.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\CompanyController::destroy
* @see app/Http/Controllers/Api/CompanyController.php:86
* @route '/api/company'
*/
destroy.delete = (options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(options),
    method: 'delete',
})

/**
* @see \App\Http\Controllers\Api\CompanyController::destroy
* @see app/Http/Controllers/Api/CompanyController.php:86
* @route '/api/company'
*/
const destroyForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Api\CompanyController::destroy
* @see app/Http/Controllers/Api/CompanyController.php:86
* @route '/api/company'
*/
destroyForm.delete = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

destroy.form = destroyForm

const company = {
    show: Object.assign(show, show),
    needsSetup: Object.assign(needsSetup, needsSetup),
    update: Object.assign(update, update),
    destroy: Object.assign(destroy, destroy),
}

export default company