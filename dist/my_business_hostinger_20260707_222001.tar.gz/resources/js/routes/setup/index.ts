import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../wayfinder'
/**
* @see routes/web.php:35
* @route '/setup-empresa'
*/
export const company = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: company.url(options),
    method: 'get',
})

company.definition = {
    methods: ["get","head"],
    url: '/setup-empresa',
} satisfies RouteDefinition<["get","head"]>

/**
* @see routes/web.php:35
* @route '/setup-empresa'
*/
company.url = (options?: RouteQueryOptions) => {
    return company.definition.url + queryParams(options)
}

/**
* @see routes/web.php:35
* @route '/setup-empresa'
*/
company.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: company.url(options),
    method: 'get',
})

/**
* @see routes/web.php:35
* @route '/setup-empresa'
*/
company.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: company.url(options),
    method: 'head',
})

/**
* @see routes/web.php:35
* @route '/setup-empresa'
*/
const companyForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: company.url(options),
    method: 'get',
})

/**
* @see routes/web.php:35
* @route '/setup-empresa'
*/
companyForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: company.url(options),
    method: 'get',
})

/**
* @see routes/web.php:35
* @route '/setup-empresa'
*/
companyForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: company.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

company.form = companyForm

const setup = {
    company: Object.assign(company, company),
}

export default setup